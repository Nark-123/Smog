package smog;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

/** Representation boundaries, exact distances, immutable ownership and v1 wire compatibility. */
public final class CompactGeometryTests {
    static int checks;
    static void check(boolean ok, String why) { checks++; if (!ok) throw new AssertionError(why); }
    static void roundTrip(int[] labels, int nodes) throws Exception {
        VoxelLabels compact = VoxelLabels.of(labels);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        for (int p = 0; p < 512; p++) out.writeShort(labels[p]);
        VoxelLabels decoded = VoxelLabels.read(new DataInputStream(new ByteArrayInputStream(bytes.toByteArray())),
            nodes, new int[nodes]);
        for (int p = 0; p < 512; p++) {
            check(compact.get(p) == labels[p], "Compaction changed membership");
            check(decoded.get(p) == labels[p], "Decode changed membership");
        }
        int[] copy = compact.toArray();
        copy[0] = 12345;
        check(compact.get(0) == labels[0], "Mutable compact ownership");
    }
    public static void main(String[] args) throws Exception {
        int[] labels = new int[512];
        roundTrip(labels, 1);
        check(VoxelLabels.of(labels).payloadBytes() == 0, "Uniform allocated voxel labels");
        Arrays.fill(labels, -1);
        roundTrip(labels, 0);
        for (int p = 0; p < 512; p++) labels[p] = p;
        roundTrip(labels, 512);
        check(VoxelLabels.of(labels).payloadBytes() == 1024, "512-node case not wide");
        for (int p = 0; p < 512; p++) labels[p] = (p % 256) - 1;
        roundTrip(labels, 255);
        check(VoxelLabels.of(labels).payloadBytes() == 512, "Unsigned byte boundary");
        labels[511] = 255;
        roundTrip(labels, 256);
        check(VoxelLabels.of(labels).payloadBytes() == 1024, "Sentinel collision at node 255");
        Random random = new Random(91017);
        for (int n = 0; n < 100; n++) {
            int nodes = 1 + random.nextInt(512);
            for (int p = 0; p < 512; p++) labels[p] = random.nextInt(nodes + 1) - 1;
            roundTrip(labels, nodes);
        }
        byte[] distance = new byte[512];
        check(VoxelDistance.of(distance).payloadBytes() == 0, "Uniform distance allocated");
        for (int p = 0; p < 512; p++) distance[p] = (byte) (p & 255);
        VoxelDistance packed = VoxelDistance.of(distance);
        check(packed.payloadBytes() == 512, "Nonuniform distances collapsed");
        for (int p = 0; p < 512; p++) check(packed.get(p) == (distance[p] & 255), "Distance changed");
        distance[0] = 17;
        check(packed.get(0) == 0, "Distance input remains mutable");
        LazyIntMap<Double> lazy = new LazyIntMap<>();
        check(lazy.isEmpty(), "Lazy map not empty");
        lazy.put(9, 3.0); lazy.put(1, 4.0);
        check(lazy.entrySet().iterator().next().getKey() == 1, "Map lost deterministic order");
        Iterator<Map.Entry<Integer, Double>> iterator = lazy.entrySet().iterator();
        iterator.next(); iterator.remove();
        check(lazy.size() == 1 && lazy.get(9) == 3, "Map iterator removal");
        lazy.clear(); check(lazy.isEmpty(), "Lazy clear failed");
        System.out.println("PASS CompactGeometryTests checks=" + checks);
    }
}
