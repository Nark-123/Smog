package smog;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** Controlled update frequency; no claim about edit frequency on a real GTNH server. */
public final class CacheRewriteBenchmark {
    public static void main(String[] args) throws Exception {
        int version=Integer.parseInt(args[0]); System.setProperty("smog.geometryPackVersion",Integer.toString(version));
        RestoreBenchmark.setup("open",512);
        byte[][] templates=RestoreBenchmark.templates(); List<GeometryPack> packs=new ArrayList<>();
        for(int z=0;z<4;z++) for(int y=0;y<4;y++) for(int x=0;x<4;x++) for(int slot=0;slot<8;slot++)
            packs.add(RestoreBenchmark.shifted(templates[slot],new CubeKey(0,x,y,z),slot));
        Path directory=Files.createTempDirectory(Paths.get("build"),"rewrite-profile-");
        try(GeometryCache cache=new GeometryCache(directory,0,RestoreBenchmark.config,32L*1048576)) {
            for(GeometryPack p:packs) cache.store(p);
            cache.flush().get(15,TimeUnit.SECONDS);
            RestartMetrics metrics=new RestartMetrics(); cache.syncMetrics(metrics);
            System.out.print("[");
            for(int phase=0;phase<2;phase++) {
                double regions=metrics.get("cache_write_regions"),cells=metrics.get("cache_write_cells"),bytes=metrics.get("cache_write_bytes");
                long before=RestoreBenchmark.ALLOC.getThreadAllocatedBytes(Thread.currentThread().getId()),start=System.nanoTime();
                for(int i=0;i<32;i++) {
                    cache.store(packs.get(i));
                    if(phase==0) cache.flush().get(15,TimeUnit.SECONDS);
                }
                if(phase==1) cache.flush().get(15,TimeUnit.SECONDS);
                double ms=(System.nanoTime()-start)/1e6;
                cache.syncMetrics(metrics);
                System.out.printf(Locale.ROOT,"%s{\"version\":%d,\"mode\":\"%s\",\"updates\":32,\"region_writes\":%.0f,\"encoded_cells\":%.0f,\"write_bytes\":%.0f,\"elapsed_ms\":%.3f,\"file_bytes\":%d}",phase==0?"":",",version,phase==0?"flush_each":"coalesced",metrics.get("cache_write_regions")-regions,metrics.get("cache_write_cells")-cells,metrics.get("cache_write_bytes")-bytes,ms,Files.size(directory.resolve("pack-0-0-0.gpk")));
            }
            System.out.println("]");
        }
    }
}
