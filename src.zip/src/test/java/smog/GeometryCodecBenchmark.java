package smog;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Locale;
import java.util.zip.CRC32;

/** Warm file read + integrity + decode, v1 zlib versus uncompressed CRC records. */
public final class GeometryCodecBenchmark {
    static void raw(DataOutput out, byte[] bytes) throws Exception {
        CRC32 crc=new CRC32(); crc.update(bytes);
        out.writeInt(bytes.length); out.writeInt((int)crc.getValue()); out.write(bytes);
    }
    static byte[] raw(DataInput in) throws Exception {
        int size=in.readInt(), expected=in.readInt();
        if(size<0 || size>RecordCodec.MAX) throw new IOException("Raw size");
        byte[] bytes=new byte[size]; in.readFully(bytes); CRC32 crc=new CRC32(); crc.update(bytes);
        if((int)crc.getValue()!=expected) throw new IOException("Raw CRC");
        return bytes;
    }
    public static void main(String[] args) throws Exception {
        Path directory=Files.createTempDirectory(Paths.get("build"),"codec-");
        boolean comma=false; System.out.print("[");
        for(String scene:new String[]{"open","rooms","cavities","dense"}) {
            RestoreBenchmark.setup(scene,1024);
            byte[][] templates=RestoreBenchmark.templates();
            ByteArrayOutputStream bytes=new ByteArrayOutputStream(); DataOutputStream data=new DataOutputStream(bytes);
            data.writeByte(8); for(byte[] pack:templates) data.write(pack); data.flush(); byte[] cube=bytes.toByteArray();
            for(String codec:new String[]{"zlib","raw"}) {
                Path file=directory.resolve(scene+"-"+codec);
                try(DataOutputStream out=new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(file)))) {
                    for(int i=0;i<128;i++) if(codec.equals("zlib")) RecordCodec.write(out,cube); else raw(out,cube);
                }
                long before=RestoreBenchmark.ALLOC.getThreadAllocatedBytes(Thread.currentThread().getId());
                long start=System.nanoTime();
                for(int repeat=0;repeat<8;repeat++) {
                    try(DataInputStream in=new DataInputStream(new BufferedInputStream(Files.newInputStream(file)))) {
                        for(int i=0;i<128;i++) {
                            byte[] record=codec.equals("zlib")?RecordCodec.read(in):raw(in);
                            DataInputStream decoded=new DataInputStream(new ByteArrayInputStream(record));
                            if(decoded.readUnsignedByte()!=8) throw new AssertionError();
                            for(int slot=0;slot<8;slot++) GeometryPack.read(decoded,0);
                            if(decoded.read()!=-1) throw new AssertionError();
                        }
                    }
                }
                long allocated=RestoreBenchmark.ALLOC.getThreadAllocatedBytes(Thread.currentThread().getId())-before;
                if(comma) System.out.print(","); comma=true;
                System.out.printf(Locale.ROOT,"{\"scene\":\"%s\",\"codec\":\"%s\",\"record_raw_bytes\":%d,\"file_bytes\":%d,\"cells\":8192,\"read_decode_ms\":%.3f,\"allocated_bytes\":%d}",scene,codec,cube.length,Files.size(file),(System.nanoTime()-start)/1e6,allocated);
            }
        }
        System.out.println("]");
    }
}
