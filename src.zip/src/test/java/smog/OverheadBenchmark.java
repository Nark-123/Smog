package smog;

import java.lang.reflect.Method;
import java.util.Locale;

/** Same harness runs against the exact delivered and optimized core, in separate JVMs. */
public final class OverheadBenchmark {
    private static volatile long sink;
    public static void main(String[] args) throws Exception {
        com.sun.management.ThreadMXBean mx = RestoreBenchmark.ALLOC;
        long thread = Thread.currentThread().getId();
        try (DimensionState s = new DimensionState(0, FastColdRestartTests.CONFIG, FastColdRestartTests.world())) {
            Method add = null;
            try { add = DimensionState.class.getDeclaredMethod("addFrame", DimensionState.Frame.class); add.setAccessible(true); }
            catch (NoSuchMethodException oldCore) { /* original deque, scanned at publication */ }
            DimensionState.Cell[] cells = new DimensionState.Cell[50000];
            for (int i = 0; i < cells.length; i++) cells[i] = s.cell(new CellKey(0, i, 0, 0), true);
            long allocated = mx.getThreadAllocatedBytes(thread), start = System.nanoTime();
            for (int i = 0; i < 2800; i++) {
                DimensionState.Frame f = new DimensionState.Frame(new BlockPos[] {cells[i % 32].key.block(0),
                    cells[i % 32].key.block(1), cells[33].key.block(0)}, new double[] {.4, .6, 0}, 2);
                if (add == null) s.frames.addLast(f); else add.invoke(s, f);
            }
            long enqueue = System.nanoTime() - start;
            Method boundary = DimensionState.class.getDeclaredMethod("publicationMassBoundary", DimensionState.Cell.class);
            boundary.setAccessible(true);
            start = System.nanoTime();
            for (DimensionState.Cell c : cells) sink += ((Long)boundary.invoke(s, c)).longValue();
            long lookup = System.nanoTime() - start;
            System.out.printf(Locale.ROOT, "{\"kind\":\"frames\",\"cells\":50000,\"frames\":2800,\"enqueue_ms\":%.6f,\"lookup_ms\":%.6f,\"allocated_bytes\":%d,\"checksum\":%d}%n",
                enqueue / 1e6, lookup / 1e6, mx.getThreadAllocatedBytes(thread) - allocated, sink);
        }
        // Escape the objects: allocating two unused accumulators models Entry construction.
        EdgeAccumulator[] accumulators = new EdgeAccumulator[100000];
        long allocated = mx.getThreadAllocatedBytes(thread), start = System.nanoTime();
        for (int i = 0; i < accumulators.length; i++) accumulators[i] = new EdgeAccumulator();
        for (EdgeAccumulator a : accumulators) sink += a.records().length;
        System.out.printf(Locale.ROOT, "{\"kind\":\"empty_contacts\",\"cells\":50000,\"ms\":%.6f,\"allocated_bytes\":%d,\"checksum\":%d}%n",
            (System.nanoTime() - start) / 1e6, mx.getThreadAllocatedBytes(thread) - allocated, sink);
    }
}
