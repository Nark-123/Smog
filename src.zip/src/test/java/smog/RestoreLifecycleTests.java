package smog;

import java.lang.reflect.Field;
import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

/** Real cache IO, synthetic chunk events and live sparse graph. */
public final class RestoreLifecycleTests {
    static void check(boolean value, String why) { if (!value) throw new AssertionError(why); }
    static void cleanColumn() throws Exception {
        Path path = OptimisticRestoreTests.cache();
        Checkpoint.Data data = FastColdRestartTests.seed(path, OptimisticRestoreTests.halo());
        SparseTests.World world = OptimisticRestoreTests.halo();
        CubeKey clean = new CubeKey(0, -1, -1, -1);
        world.ready.remove(clean);
        try (DimensionState state = FastColdRestartTests.restore(data, path, world, true, false)) {
            OptimisticRestoreTests.plan(state, data);
            FastColdRestartTests.drain(state);
            check(state.restartMetrics.get("validation_waiting") > 0, "Fixture did not sleep");
            check(!state.cubes.containsKey(clean), "Clean section has a SMOG record");
            int records = state.cubes.size();
            world.ready.add(clean);
            state.columnEvent(-1, -1, false);
            FastColdRestartTests.drain(state);
            check(state.restartMetrics.get("validation_waiting") == 0, "Clean vertical halo did not wake validation");
            check(state.cubes.size() == records, "Readiness allocated empty CubeRecords");
            DimensionState.Cell first = state.cell(data.cells.get(0).key, false);
            check(first.geometry.verification == DimensionState.GeometryState.VALIDATED, "Matching halo not validated");
            world.ready.remove(clean);
            state.columnEvent(-1, -1, true);
            check(first.geometry.verification == DimensionState.GeometryState.DIRTY, "Clean unload missed topology notification");
        }
    }
    static void cleanMismatch() throws Exception {
        Path path = OptimisticRestoreTests.cache();
        Checkpoint.Data data = FastColdRestartTests.seed(path, OptimisticRestoreTests.halo());
        SparseTests.World world = OptimisticRestoreTests.halo();
        CubeKey clean = new CubeKey(0, -1, 0, 0);
        world.ready.remove(clean);
        try (DimensionState state = FastColdRestartTests.restore(data, path, world, true, false)) {
            OptimisticRestoreTests.plan(state, data);
            FastColdRestartTests.drain(state);
            world.change(clean, SparseTests.air());
            world.ready.add(clean);
            state.columnEvent(-1, 0, false);
            FastColdRestartTests.drain(state);
            check(state.restartMetrics.get("validation_dirty") > 0, "Clean changed neighbor did not rebuild");
            check(state.cell(new CellKey(0, -1, 0, 0), false) != null, "Mass frontier did not activate clean neighbor");
            SparseTests.near(state.balanceError(), 0, 1e-9, "Clean frontier ledger");
        }
    }
    static void reload(boolean changed) throws Exception {
        Path path = OptimisticRestoreTests.cache();
        Checkpoint.Data data = FastColdRestartTests.seed(path, OptimisticRestoreTests.halo());
        SparseTests.World world = OptimisticRestoreTests.halo();
        try (DimensionState state = FastColdRestartTests.restore(data, path, world, true, false)) {
            FastColdRestartTests.drain(state);
            long jobs = state.geometryMetrics.jobsStarted, exact = state.geometryMetrics.coldExactCount;
            check(state.queueAddMass(data.cells.get(0).key.block(0), 3), "Fixture event rejected");
            world.unload(state, FastColdRestartTests.CUBE);
            check(state.parkedMass() == 80, "Unload lost active mass");
            if (changed) world.change(FastColdRestartTests.CUBE, new byte[4096]);
            world.load(state, FastColdRestartTests.CUBE);
            FastColdRestartTests.drain(state);
            check(state.geometryMetrics.coldExactCount == exact, "Reload used coldExactMass");
            if (changed) {
                check(state.trappedMass() == 83 && state.pendingMass() == 0, "Session mismatch bypassed remap/events: trapped=" + state.trappedMass() + " pending=" + state.pendingMass());
                check(state.geometryMetrics.jobsStarted > jobs, "Changed runtime cache did not fall back");
            } else {
                check(state.restartMetrics.get("cache_reactivation_cells") == 8, "Reload missed fast transaction");
                check(state.geometryMetrics.jobsStarted == jobs, "Unchanged reload ran CellBuild");
                check(state.liveMass() == 83, "Reload event applied incorrectly: live=" + state.liveMass() + " pending=" + state.pendingMass() + " trapped=" + state.trappedMass());
            }
            SparseTests.near(state.balanceError(), 0, 1e-9, "Reload ledger");
        }
    }
    static void savedNeighborFront() throws Exception {
        Path path=OptimisticRestoreTests.cache();
        SparseTests.World world=OptimisticRestoreTests.halo();
        world.change(new CubeKey(0,1,0,0),SparseTests.air());
        Checkpoint.Data data;
        java.util.SortedMap<String,Double> topology;
        FastColdRestartTests.options(true,false,false);
        try(DimensionState seed=new DimensionState(0,FastColdRestartTests.CONFIG,world)) {
            seed.geometryCache(path);
            for(int x=0;x<4;x++) for(int y=0;y<2;y++) for(int z=0;z<2;z++)
                seed.queueAddMass(new CellKey(0,x,y,z).block(0),10);
            FastColdRestartTests.drain(seed); seed.geometryCache.flush().get(5,TimeUnit.SECONDS);
            data=FastColdRestartTests.snapshot(seed); topology=seed.topology();
        }
        try(DimensionState state=FastColdRestartTests.restore(data,path,world,true,false)) {
            OptimisticRestoreTests.plan(state,data);
            DimensionState.Cell border=state.cell(new CellKey(0,1,0,0),false);
            check((border.frontierFaces & (1<<1))==0,"Saved neighbor incorrectly watched as an expansion front");
            FastColdRestartTests.drain(state);
            check(state.topology().equals(topology),"Skipping saved expansion front changed contacts");
            check(state.liveMass()==160,"Saved neighbor did not restore");
            FastColdRestartTests.near(state.balanceError(),0,"Saved front ledger");
        }
    }
    static void closeFlush() throws Exception {
        Path path = OptimisticRestoreTests.cache();
        FastColdRestartTests.options(true, false, false);
        SparseTests.World world = FastColdRestartTests.world();
        try (DimensionState state = new DimensionState(0, FastColdRestartTests.CONFIG, world)) {
            state.geometryCache(path);
            for (int i = 0; i < 8; i++) state.queueAddMass(new CellKey(0, i&1, (i>>1)&1, (i>>2)&1).block(0), 10);
            FastColdRestartTests.drain(state);
            // No flush() and no 200 ms sleep before close.
        }
        try (GeometryCache cache = new GeometryCache(path, 0, FastColdRestartTests.CONFIG, 1048576)) {
            GeometryCache.Lookup lookup = cache.request(FastColdRestartTests.CUBE).get(5, TimeUnit.SECONDS);
            check(lookup.status == GeometryCache.Status.OK && lookup.cells.size() == 8, "Close lost queued cache writes");
        }
    }
    static void boundedClose() throws Exception {
        System.setProperty("smog.geometryShutdownMs", "30");
        GeometryCache cache = new GeometryCache(OptimisticRestoreTests.cache(), 0, FastColdRestartTests.CONFIG, 1048576);
        Field field = GeometryCache.class.getDeclaredField("io"); field.setAccessible(true);
        ExecutorService io = (ExecutorService) field.get(cache);
        CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1);
        io.execute(() -> { entered.countDown(); try { release.await(); } catch (InterruptedException ignored) {} });
        check(entered.await(2, TimeUnit.SECONDS), "IO fixture did not start");
        long start = System.nanoTime();
        cache.close(); release.countDown();
        check(System.nanoTime() - start < TimeUnit.SECONDS.toNanos(1), "Cache shutdown was unbounded");
        RestartMetrics metrics = new RestartMetrics(); cache.syncMetrics(metrics);
        check(metrics.get("cache_shutdown_timeout") == 1, "Timeout was not observable");
        System.clearProperty("smog.geometryShutdownMs");
    }
    public static void main(String[] args) throws Exception {
        String test = args.length == 0 ? "all" : args[0];
        if (test.equals("all") || test.equals("clean")) { cleanColumn(); cleanMismatch(); }
        if (test.equals("all") || test.equals("reload")) { reload(false); reload(true); savedNeighborFront(); }
        if (test.equals("all") || test.equals("close")) { closeFlush(); boundedClose(); }
        System.out.println("PASS RestoreLifecycleTests " + test);
    }
}
