package smog;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.smogmod.compat.gt5u.PendingPulse;
import org.smogmod.persistence.WorldStore;

/** Shutdown and durable generation retention; synthetic provider, real filesystem. */
public final class SaveLifecycleRegressionTests {
    static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    static void shutdown() throws Exception {
        System.setProperty("smog.bootstrapEnabled", "true");
        SparseTests.World world = FastColdRestartTests.world();
        Path path = Files.createTempDirectory(java.nio.file.Paths.get("build"), "expired-shutdown-");
        List<PendingPulse> pending = new ArrayList<>();
        BlockPos point = new BlockPos(0, 1, 1, 1);
        pending.add(new PendingPulse(point, 17, false, true));
        try (DimensionState state = new DimensionState(0, FastColdRestartTests.CONFIG, world)) {
            state.queueAddMass(point, 23);
            state.setSourceRate(point, 2);
            for (int n = 0; n < 7; n++) state.tick(0, 20, false);
            long ticks = state.gameTicks(), steps = state.iteration();
            double generated = state.generatedMass();
            WorldStore store = new WorldStore(path);
            store.markDirty();
            store.saveAndAwaitForShutdown(state, pending, 30000);
            check(state.gameTicks() == ticks && state.iteration() == steps, "Shutdown advanced clocks");
            List<PendingPulse> restored = new ArrayList<>();
            try (DimensionState loaded = new WorldStore(path).load(0, world, restored)) {
                check(loaded.gameTicks() == ticks, "Saved wrong game clock");
                SparseTests.near(loaded.generatedMass(), generated, 1e-12, "Lost events at shutdown");
                check(restored.size() == 1 && restored.get(0).amount == 17, "Lost pending pulse");
            }
        }
    }

    static long payloads(Path path, String name) throws Exception {
        try (java.util.stream.Stream<Path> files = Files.walk(path)) {
            return files.filter(p -> Files.isRegularFile(p) && p.getFileName().toString().matches(name)).count();
        }
    }

    static void retention() throws Exception {
        System.clearProperty("smog.bootstrapEnabled");
        SparseTests.World world = FastColdRestartTests.world();
        Path path = Files.createTempDirectory(java.nio.file.Paths.get("build"), "bundle-retention-");
        Path incomplete = path.resolve("bundle-" + UUID.randomUUID());
        Files.createDirectories(incomplete.resolve("core"));
        Files.write(incomplete.resolve("core/partial.tmp"), new byte[] { 1 });
        Path active = path.resolve("bundle-" + UUID.randomUUID());
        Files.createDirectories(active.resolve("core"));
        Files.write(active.resolve("core/manifest"), new byte[] { 1 });
        Files.write(active.resolve("pending.bin"), new byte[] { 1 });
        Files.write(active.resolve("pending.sha256"), new byte[] { 1 });
        List<PendingPulse> pending = new ArrayList<>();
        try (java.nio.channels.FileChannel lease = java.nio.channels.FileChannel.open(active.resolve(".in-progress"),
            java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.WRITE);
            DimensionState state = new DimensionState(0, FastColdRestartTests.CONFIG, world)) {
            java.nio.channels.FileLock lock = lease.lock();
            WorldStore store = new WorldStore(path);
            for (int n = 1; n <= 100; n++) {
                state.queueAddMass(new BlockPos(0, 1, 1, 1), 1);
                store.markDirty();
                store.saveAndAwaitForShutdown(state, pending, 30000);
                check(payloads(path,"generation-[0-9]+\\.smog") == Math.min(2,n), "Unbounded checkpoint payloads at save " + n);
                check(payloads(path,"pending\\.bin") == Math.min(2,n)+1, "Unbounded pulse payloads at save " + n);
            }
            check(Files.exists(active.resolve("pending.bin")), "Removed another unfinished full payload");
            lock.release(); // Model process death: payload remains, OS lease is gone.
            check(Files.exists(incomplete.resolve("core/partial.tmp")), "Removed incomplete operation");
            String current = new String(Files.readAllBytes(path.resolve("CURRENT")), StandardCharsets.US_ASCII);
            Files.write(path.resolve(current).resolve("pending.bin"), new byte[] { 0 });
            WorldStore recovered = new WorldStore(path);
            try (DimensionState loaded = recovered.load(0, world, new ArrayList<PendingPulse>())) {
                SparseTests.near(loaded.generatedMass(), 99, 1e-12, "Previous generation not retained");
                recovered.markDirty();
                recovered.saveAndAwaitForShutdown(loaded, new ArrayList<PendingPulse>(), 30000);
                check(payloads(path,"generation-[0-9]+\\.smog")==2 && payloads(path,"pending\\.bin")==2,
                    "Corrupt CURRENT payload leaked after recovery commit");
            }
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 0 || args[0].equals("shutdown")) shutdown();
        if (args.length == 0 || args[0].equals("retention")) retention();
        System.out.println("PASS SaveLifecycleRegressionTests (shutdown clocks, 100 saves, fallback)");
    }
}
