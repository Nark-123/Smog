package smog;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Fair region turns, immutable rewrite reuse, bounded failures and derivative isolation. */
public final class CacheFairnessTests {
    private static int checks;
    private static void check(boolean ok, String why) { checks++; if (!ok) throw new AssertionError(why); }
    private static byte[][] templates;
    private static GeometryPack pack(int x, int slot) throws Exception {
        return RestoreBenchmark.shifted(templates[slot], new CubeKey(0, x, 0, 0), slot);
    }
    private static void fairness() throws Exception {
        Path dir = Files.createTempDirectory(Paths.get("build"), "cache-fair-");
        try (GeometryCache cache = new GeometryCache(dir, 0, RestoreBenchmark.config, 32L * 1048576)) {
            cache.store(pack(0, 0)); cache.flush().get(5, TimeUnit.SECONDS);
            Field field = GeometryCache.class.getDeclaredField("io"); field.setAccessible(true);
            ScheduledExecutorService io = (ScheduledExecutorService)field.get(cache);
            CountDownLatch started = new CountDownLatch(1), release = new CountDownLatch(1);
            io.execute(() -> { started.countDown(); try { release.await(2, TimeUnit.SECONDS); }
                catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); } });
            check(started.await(1, TimeUnit.SECONDS), "IO gate not started");
            for (int x : new int[] {4, 8, 12}) for (int slot = 0; slot < 8; slot++) cache.store(pack(x, slot));
            CompletableFuture<Void> flush = cache.flush();
            Field writes = GeometryCache.class.getDeclaredField("writeRegions"); writes.setAccessible(true);
            CompletableFuture<Long> read = cache.request(new CubeKey(0, 0, 0, 0)).thenApply(result -> {
                check(result.status == GeometryCache.Status.OK, "selective read failed during rewrite");
                try { return writes.getLong(cache); } catch (IllegalAccessException failure) { throw new AssertionError(failure); }
            });
            release.countDown();
            check(read.get(5, TimeUnit.SECONDS) <= 2, "one drain turn monopolized IO ahead of demand read");
            flush.get(5, TimeUnit.SECONDS);
            for (int i = 0; i < 1000; i++) cache.store(pack(0, i % 8));
            cache.flush().get(5, TimeUnit.SECONDS);
            RestartMetrics m = new RestartMetrics(); cache.syncMetrics(m);
            check(m.get("cache_write_coalesced") >= 992, "same-cell generations not coalesced");
            check(m.get("cache_region_reuse") > 0, "unchanged written region decoded again");
            check(m.get("cache_pending_bytes") == 0 && m.get("cache_pending_regions") == 0, "flush returned with target pending");
            check(m.get("cache_read_requests") > 0 && m.get("cache_read_wait_ms") >= 0, "read queue time missing");
        }
    }
    private static void failedDisk() throws Exception {
        Path root = Files.createTempDirectory(Paths.get("build"), "cache-failed-disk-");
        Path invalid = root.resolve("not-a-directory"); Files.write(invalid, new byte[] {9});
        Path authoritative = root.resolve("authoritative");
        try (DimensionState s = new DimensionState(0, RestoreBenchmark.config, new RestoreBenchmark.World())) {
            Checkpoint.write(authoritative, FastColdRestartTests.snapshot(s), 0);
        }
        try (GeometryCache cache = new GeometryCache(invalid, 0, RestoreBenchmark.config, 1048576)) {
            cache.store(pack(0, 0));
            try { cache.flush().get(5, TimeUnit.SECONDS); throw new AssertionError("failed cache flush reported success"); }
            catch (ExecutionException expected) { check(expected.getCause() instanceof java.io.IOException, "wrong cache failure"); }
            RestartMetrics m = new RestartMetrics(); cache.syncMetrics(m);
            check(m.get("cache_write_failures") == 3 && m.get("cache_write_retries") == 2, "unbounded/missing retries");
            check(m.get("cache_flush_failed") == 1, "failed flush not diagnosed");
            check(Checkpoint.read(authoritative).data.dimension == 0, "derived cache failure damaged checkpoint");
        }
    }
    private static void readFailurePreservesFile() throws Exception {
        Path dir = Files.createTempDirectory(Paths.get("build"), "cache-read-device-fault-");
        try (GeometryCache cache = new GeometryCache(dir, 0, RestoreBenchmark.config, 1048576)) {
            cache.store(pack(0, 0)); cache.flush().get(5, TimeUnit.SECONDS);
        }
        Path file = dir.resolve("pack-0-0-0.gpk"); byte[] original = Files.readAllBytes(file);
        try (GeometryCache cache = new GeometryCache(dir, 0, RestoreBenchmark.config, 1048576,
            path -> { throw new java.io.IOException("injected device read error"); })) {
            check(cache.request(new CubeKey(0, 0, 0, 0)).get(5, TimeUnit.SECONDS).status == GeometryCache.Status.MISS,
                "device failure treated as verified corruption");
            cache.store(pack(0, 1));
            try { cache.flush().get(5, TimeUnit.SECONDS); throw new AssertionError("unreadable old region overwritten"); }
            catch (ExecutionException expected) { check(expected.getCause() instanceof java.io.IOException, "wrong device error"); }
            check(java.util.Arrays.equals(original, Files.readAllBytes(file)), "device read failure replaced previous valid gpk");
            RestartMetrics m = new RestartMetrics(); cache.syncMetrics(m);
            check(m.get("cache_read_failures") == 1, "read device error not diagnosed separately");
        }
        java.nio.file.attribute.BasicFileAttributes attributes = Files.readAttributes(file, java.nio.file.attribute.BasicFileAttributes.class);
        Object anonymous = java.lang.reflect.Proxy.newProxyInstance(getClassLoader(),
            new Class<?>[] {java.nio.file.attribute.BasicFileAttributes.class},
            (proxy, method, args) -> method.getName().equals("fileKey") ? null : method.invoke(attributes, args));
        java.lang.reflect.Method same = GeometryCache.class.getDeclaredMethod("sameFile",
            java.nio.file.attribute.BasicFileAttributes.class, java.nio.file.attribute.BasicFileAttributes.class);
        same.setAccessible(true);
        check(!((Boolean)same.invoke(null, anonymous, anonymous)), "memo trusted missing file identity");
        // Raw device errors are not relabelled as malformed compressed bytes.
        try (java.io.RandomAccessFile in = new java.io.RandomAccessFile(file.toFile(), "r")) {
            in.close();
            try { RecordCodec.read(in); throw new AssertionError("closed device unexpectedly read"); }
            catch (java.io.IOException expected) { check(!(expected instanceof RecordCodec.InvalidRecord), "device error misclassified as CRC failure"); }
        }
    }
    private static ClassLoader getClassLoader() { return CacheFairnessTests.class.getClassLoader(); }

    private static void bulkAndCorruption() throws Exception {
        Path dir = Files.createTempDirectory(Paths.get("build"), "cache-bulk-");
        try (GeometryCache cache = new GeometryCache(dir, 0, RestoreBenchmark.config, 32L * 1048576)) {
            for (int cell = 0; cell < 80008; cell++) {
                cache.store(pack(cell / 8, cell % 8));
                if (cell % 2048 == 2047) {
                    try { cache.flush().get(30, TimeUnit.SECONDS); }
                    catch (java.util.concurrent.TimeoutException timeout) {
                        for (String name : new String[] {"pending", "activeKey", "scheduled", "draining", "barriers"}) {
                            Field f = GeometryCache.class.getDeclaredField(name); f.setAccessible(true);
                            Object value = f.get(cache);
                            System.err.println("cache_timeout cell=" + cell + " " + name + "="
                                + (value instanceof java.util.Map ? ((java.util.Map<?, ?>)value).size() : value));
                        }
                        for (java.util.Map.Entry<Thread, StackTraceElement[]> e : Thread.getAllStackTraces().entrySet())
                            if (e.getKey().getName().equals("smog-geometry-cache")) for (StackTraceElement stack : e.getValue()) System.err.println(stack);
                        throw timeout;
                    }
                }
            }
            cache.flush().get(10, TimeUnit.SECONDS);
            RestartMetrics m = new RestartMetrics(); cache.syncMetrics(m);
            check(m.get("cache_write_updates") == 80008 && m.get("cache_write_dropped") == 0, "bulk cache writes dropped");
            check(m.get("cache_pending_bytes") <= 32L * 1048576, "pending memory exceeded cap");
            Path file = dir.resolve("pack-0-0-0.gpk");
            byte[] good = Files.readAllBytes(file); Files.write(file, new byte[] {1, 2, 3});
            try (GeometryCache reader = new GeometryCache(dir, 0, RestoreBenchmark.config, 1048576)) {
                check(reader.request(new CubeKey(0, 0, 0, 0)).get(5, TimeUnit.SECONDS).status == GeometryCache.Status.CORRUPT,
                    "corrupt gpk trusted");
            }
            Files.write(file, good);
            for (int i = 0; i < 10; i++) {
                cache.store(pack(0, i % 8)); CompletableFuture<Void> flush = cache.flush();
                try (GeometryCache reader = new GeometryCache(dir, 0, RestoreBenchmark.config, 1048576)) {
                    check(reader.request(new CubeKey(0, 0, 0, 0)).get(5, TimeUnit.SECONDS).status == GeometryCache.Status.OK,
                        "atomic replace exposed partial file");
                }
                flush.get(5, TimeUnit.SECONDS);
            }
            cache.syncMetrics(m);
            System.out.println("bulk_write_updates=" + m.get("cache_write_updates") + " encoded_cells=" + m.get("cache_write_cells")
                + " rewrite_read_bytes=" + m.get("cache_rewrite_read_bytes") + " read_wait_ms=" + m.get("cache_read_wait_ms"));
        }
    }
    public static void main(String[] args) throws Exception {
        RestoreBenchmark.setup("open", 80008); templates = RestoreBenchmark.templates();
        fairness(); failedDisk(); readFailurePreservesFile(); bulkAndCorruption();
        System.out.println("CACHE_FAIRNESS_PASS checks=" + checks);
    }
}
