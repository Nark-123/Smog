package smog;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/** Same v1 dataset and budget on original and new cores. Synthetic, warm filesystem cache. */
public final class RestoreBenchmark {
    static final int DIM = 0;
    static String scene;
    static int count, cubes, nx, ny, nz;
    static SmogConfig config;
    static byte[] air;
    static byte[] atmosphere;
    static final com.sun.management.ThreadMXBean ALLOC = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();

    static class World implements WorldSnapshotProvider {
        long reads;
        final LinkedHashMap<CubeKey, ImmutableCubeSnapshot> cache = new LinkedHashMap<CubeKey, ImmutableCubeSnapshot>(16,.75f,true) {
            protected boolean removeEldestEntry(Map.Entry<CubeKey, ImmutableCubeSnapshot> e) { return size() > 2048; }
        };
        public boolean isReady(CubeKey key) {
            if (scene.equals("partial") && key.x >= 0 && key.x < nx && key.x % 2 != 0) return false;
            if (scene.equals("bases")) return key.dimension == 0 && key.x >= 0 && key.x < nx * 4
                && key.y >= 0 && key.y < ny * 4 && key.z >= 0 && key.z < nz * 4
                && key.x % 4 == 0 && key.y % 4 == 0 && key.z % 4 == 0;
            return key.dimension == 0 && key.x >= -1 && key.x <= nx && key.y >= -1 && key.y <= ny && key.z >= -1 && key.z <= nz;
        }
        public ImmutableCubeSnapshot snapshotIfReady(CubeKey key) {
            if (!isReady(key)) throw new AssertionError("Forced unavailable read");
            reads++;
            ImmutableCubeSnapshot found = cache.get(key);
            if (found == null) { found = new ImmutableCubeSnapshot(key, 1, 1, air, atmosphere); cache.put(key, found); }
            return found;
        }
        public boolean matchesSnapshot(CubeKey key, ImmutableCubeSnapshot snapshot) {
            return snapshot != null && isReady(key) && snapshot.epoch == 1 && snapshot.revision == 1;
        }
    }
    static void setup(String name, int cells) {
        scene = name; count = cells; cubes = cells / 8;
        nx = Math.min(16, cubes); ny = Math.min(16, (cubes + nx - 1) / nx);
        nz = (cubes + nx * ny - 1) / (nx * ny);
        config = (name.equals("open") || name.equals("obstacles") || name.equals("partial") || name.equals("bases")
            || name.equals("atmosphere")) ? SmogConfig.builder().mode(SmogConfig.COMPONENT)
                .openMask(name.equals("atmosphere") ? SmogConfig.Y_PLUS : 0).build() : SmogConfig.throat8();
        air = new byte[4096];
        atmosphere = new byte[4096];
        Random random = new Random(123450);
        for (int z = 0; z < 16; z++) for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            boolean value = true;
            if (name.equals("obstacles")) value = !((x % 8 == 3 || x % 8 == 4) && (z % 8 == 3 || z % 8 == 4));
            if (name.equals("rooms")) value = x % 8 != 3 || (y % 8 < 2 && z % 8 == 2);
            if (name.equals("cavities")) value = x % 4 < 2 && y % 4 < 2 && z % 4 < 2;
            if (name.equals("dense")) value = random.nextDouble() > .72;
            air[x + 16*y + 256*z] = (byte) (value ? 1 : 0);
            if (name.equals("atmosphere") && y % 8 == 7) atmosphere[x + 16*y + 256*z] = SmogConfig.Y_PLUS;
        }
    }
    static CubeKey cube(int index) {
        int stride = scene.equals("bases") ? 4 : 1;
        return new CubeKey(0, (index % nx) * stride, (index / nx % ny) * stride, (index / (nx * ny)) * stride);
    }
    static CellKey key(CubeKey cube, int slot) {
        return new CellKey(0, cube.x*2+(slot&1), cube.y*2+((slot>>1)&1), cube.z*2+((slot>>2)&1));
    }
    static byte[][] templates() throws Exception {
        byte[][] result = new byte[8][];
        try (DimensionState state = new DimensionState(0, config, new World())) {
            for (int slot = 0; slot < 8; slot++) {
                CellBuild build = new CellBuild(state, state.cell(key(new CubeKey(0,0,0,0), slot), true));
                while (!build.ready) build.advance();
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                build.pack().write(new DataOutputStream(bytes));
                result[slot] = bytes.toByteArray();
            }
        }
        return result;
    }
    static GeometryPack shifted(byte[] template, CubeKey cube, int slot) throws Exception {
        byte[] bytes = template.clone();
        java.nio.ByteBuffer buffer = java.nio.ByteBuffer.wrap(bytes);
        CellKey key = key(cube, slot);
        buffer.putInt(0,key.x); buffer.putInt(4,key.y); buffer.putInt(8,key.z);
        int nodeCount = buffer.getShort(12) & 65535;
        int contactsAt = 14 + 1536 + 12 * nodeCount;
        int dependenciesAt = contactsAt + 4 + 16 * buffer.getInt(contactsAt);
        int deps = bytes[dependenciesAt] & 255, offset = dependenciesAt + 1;
        for (int i = 0; i < deps; i++) {
            buffer.putInt(offset, buffer.getInt(offset)+cube.x);
            buffer.putInt(offset+4, buffer.getInt(offset+4)+cube.y);
            buffer.putInt(offset+8, buffer.getInt(offset+8)+cube.z);
            offset += 13 + (bytes[offset + 12] == 0 ? 0 : 32);
        }
        if (offset != bytes.length) throw new AssertionError("Template dependency bounds");
        return GeometryPack.read(new DataInputStream(new ByteArrayInputStream(bytes)), 0);
    }
    static Path data(Path root, byte[][] templates) throws Exception {
        Path directory = root.resolve(scene+"-"+count);
        if (Files.exists(directory.resolve("READY"))) return directory;
        Files.createDirectories(directory);
        Map<CubeKey, Map<CellKey, GeometryPack>> regions = new LinkedHashMap<>();
        Method write = GeometryCache.class.getDeclaredMethod("writeRegion", CubeKey.class, Map.class);
        write.setAccessible(true);
        // Setup only. One region at a time, no active graph or concurrent cache worker.
        try (GeometryCache cache = new GeometryCache(directory, 0, config, 32L*1048576)) {
            for (int index = 0; index < cubes; index++) {
                CubeKey cube = cube(index), region = new CubeKey(0,cube.x/4,cube.y/4,cube.z/4);
                Map<CellKey, GeometryPack> group = regions.computeIfAbsent(region, k -> new LinkedHashMap<>());
                for (int slot = 0; slot < 8; slot++) {
                    GeometryPack pack = shifted(templates[slot],cube,slot); group.put(pack.key,pack);
                }
                if (group.size() == 512) { write.invoke(cache,region,group); regions.remove(region); }
            }
            for (Map.Entry<CubeKey, Map<CellKey,GeometryPack>> entry : regions.entrySet()) write.invoke(cache, entry.getKey(), entry.getValue());
        }
        Files.write(directory.resolve("READY"), new byte[] {1});
        return directory;
    }
    static Checkpoint.Data checkpoint(byte[][] templates) throws Exception {
        Checkpoint.Data data = new Checkpoint.Data(); data.dimension=0; data.config=config; data.parts=20;
        DimensionState.MassRecord[] mass = new DimensionState.MassRecord[8];
        for (int slot = 0; slot < 8; slot++) {
            GeometryPack pack = GeometryPack.read(new DataInputStream(new ByteArrayInputStream(templates[slot])),0);
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(templates[slot]));
            in.skipBytes(14); int[] labels = new int[512];
            for (int p=0;p<512;p++) labels[p]=in.readShort();
            double[] values = new double[pack.volumes.length]; Arrays.fill(values,10);
            mass[slot]=new DimensionState.MassRecord(labels,pack.volumes,values);
        }
        for (int index=0;index<cubes;index++) for(int slot=0;slot<8;slot++) {
            Checkpoint.CellData cell = new Checkpoint.CellData(); cell.key=key(cube(index),slot); cell.mass=mass[slot];
            data.cells.add(cell); data.injected+=cell.mass.total();
        }
        return data;
    }
    static long gcCount() { long n=0; for(GarbageCollectorMXBean b:ManagementFactory.getGarbageCollectorMXBeans()) n+=Math.max(0,b.getCollectionCount()); return n; }
    static long gcMillis() { long n=0; for(GarbageCollectorMXBean b:ManagementFactory.getGarbageCollectorMXBeans()) n+=Math.max(0,b.getCollectionTime()); return n; }
    static Map<Long,Long> allocation() {
        Map<Long,Long> result=new HashMap<>();
        for(long id:ALLOC.getAllThreadIds()) { long bytes=ALLOC.getThreadAllocatedBytes(id); if(bytes>=0) result.put(id,bytes); }
        return result;
    }
    static long allocated(Map<Long,Long> before) { long bytes=0; for(Map.Entry<Long,Long> e:allocation().entrySet()) bytes+=Math.max(0,e.getValue()-before.getOrDefault(e.getKey(),0L)); return bytes; }
    static double percentile(List<Double> values,double p) { Collections.sort(values); return values.get(Math.min(values.size()-1,(int)Math.ceil(values.size()*p)-1)); }
    static long voxels(DimensionState state) throws Exception {
        long bytes=0;
        for(DimensionState.CubeRecord cube:state.cubes.values()) for(DimensionState.Cell cell:cube.cells) {
            if(cell==null || cell.geometry==null) continue;
            for(String name:new String[]{"labels","distance"}) {
                java.lang.reflect.Field field=DimensionState.Geometry.class.getDeclaredField(name);
                field.setAccessible(true); Object value=field.get(cell.geometry);
                if(value instanceof int[]) bytes+=4L*((int[])value).length;
                else if(value instanceof byte[]) bytes+=((byte[])value).length;
                else { Method size=value.getClass().getDeclaredMethod("payloadBytes"); size.setAccessible(true); bytes+=(Long)size.invoke(value); }
            }
        }
        return bytes;
    }

    public static void main(String[] args) throws Exception {
        // tag scene cells dataset-root [stream|restore]
        setup(args[1],Integer.parseInt(args[2]));
        System.setProperty("smog.geometryCacheEnabled","true"); System.setProperty("smog.fastRestoreEnabled","true");
        if (System.getProperty("smog.bootstrapEnabled") == null) System.setProperty("smog.bootstrapEnabled","false");
        if (System.getProperty("smog.restoreBudgetMs") == null) System.setProperty("smog.restoreBudgetMs","2");
        byte[][] templates=templates(); Path directory=data(Paths.get(args[3]),templates);
        if(args.length>4 && args[4].equals("stream")) {
            long start=System.nanoTime(), bytes=0, decoded=0;
            try(GeometryCache cache=new GeometryCache(directory,0,config,32L*1048576)) {
                RestartMetrics metrics=new RestartMetrics();
                for(int index=0;index<cubes;index++) {
                    CubeKey cube=cube(index); GeometryCache.Lookup lookup=cache.request(cube).get(5,TimeUnit.SECONDS);
                    if(lookup.status!=GeometryCache.Status.OK) throw new AssertionError(lookup.status);
                    bytes+=lookup.bytes; decoded+=lookup.cells.size(); cache.accept(cube,lookup,metrics);
                }
                System.out.printf(Locale.ROOT,"{\"tag\":\"%s\",\"scene\":\"%s\",\"cells\":%d,\"mode\":\"stream\",\"ms\":%.3f,\"decoded_cells\":%d,\"read_bytes\":%d,\"cache_bytes\":%.0f}%n",args[0],scene,count,(System.nanoTime()-start)/1e6,decoded,bytes,metrics.get("cache_memory_bytes"));
            }
            return;
        }
        boolean paced=args.length>4 && args[4].equals("paced");
        Checkpoint.Data checkpoint=checkpoint(templates); World world=new World();
        int readyCells = 0;
        for (Checkpoint.CellData cell : checkpoint.cells) if (world.isReady(cell.key.cube())) readyCells++;
        try(DimensionState state=Checkpoint.restore(checkpoint,world)) {
            state.geometryCache(directory); state.resumeReadyCubes();
            System.gc(); long gc=gcCount(), gcTime=gcMillis(); Map<Long,Long> alloc=allocation();
            long start=System.nanoTime(), end=start+TimeUnit.SECONDS.toNanos(150);
            long cpuStart = ((com.sun.management.OperatingSystemMXBean)ManagementFactory.getOperatingSystemMXBean()).getProcessCpuTime();
            long activeNanos = 0;
            long serverCpu = ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime();
            List<Double> ticks=new ArrayList<>();
            double first=-1; long progressAt=start+TimeUnit.SECONDS.toNanos(10);
            while(state.restartMetrics.get("restart_cells_published")<readyCells) {
                long tick=System.nanoTime();
                if(paced) state.tick(2000000L,20,false); else state.geometry(2000000L);
                long active = System.nanoTime()-tick; activeNanos += active;
                ticks.add(active/1e6);
                if(first<0 && state.publications>0) first=(System.nanoTime()-start)/1e6;
                if(System.nanoTime()>progressAt) {
                    System.err.println("progress cells="+state.restartMetrics.get("restart_cells_published")
                        +" ready="+state.restartMetrics.get("restart_cells_ready")+" unchecked="+state.restartMetrics.get("restart_cells_unchecked")
                        +" steps="+state.iteration()+" parts="+state.geometryMetrics.partCalls+" fronts="+state.geometryMetrics.frontScans);
                    progressAt=System.nanoTime()+TimeUnit.SECONDS.toNanos(10);
                }
                if(System.nanoTime()>end) throw new AssertionError("150-second restore deadline; published="+state.restartMetrics.get("restart_cells_published"));
                int tickMillis = Math.max(0, Integer.getInteger("smog.benchmarkTickMs", 1));
                if (tickMillis >= 20) {
                    long remainingTick = tickMillis * 1000000L - (System.nanoTime() - tick);
                    if (remainingTick > 0) Thread.sleep(remainingTick / 1000000, (int)(remainingTick % 1000000));
                } else Thread.sleep(tickMillis);
            }
            double elapsed=(System.nanoTime()-start)/1e6;
            // Finish only the in-flight candidate, without geometry work or new game time.
            // Deferred events/epsilon and their 50/90/99% timestamps then become observable.
            int accountingPeriod = Math.max(0, Integer.getInteger("smog.benchmarkTickMs", 1));
            for (int part = 0; part < 20 && state.graph.isStepInProgress(); part++) {
                if (part != 0 && accountingPeriod >= 20) Thread.sleep(accountingPeriod);
                state.finishPendingPart(20);
            }
            System.err.println("publication_ms=" + elapsed + " accounted_ms=" + (System.nanoTime()-start)/1e6
                + " ready_cells=" + readyCells + " waiting_cells=" + (count-readyCells));
            long allocation=allocated(alloc); state.updateRestartMemoryMetrics();
            long voxelBytes=voxels(state), gcDelta=gcCount()-gc, gcTimeDelta=gcMillis()-gcTime;
            System.gc(); long heap=ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed();
            if(Math.abs(state.balanceError())>1e-6*Math.max(1,state.injectedMass())) throw new AssertionError("Mass ledger");
            System.out.printf(Locale.ROOT,"{\"tag\":\"%s\",\"scene\":\"%s\",\"cells\":%d,\"mode\":\"%s\",\"ms\":%.3f,\"cells_s\":%.1f,\"first_ms\":%.3f,\"tick_p95_ms\":%.3f,\"tick_p99_ms\":%.3f,\"tick_max_ms\":%.3f,\"allocated_bytes\":%d,\"gc_count\":%d,\"gc_ms\":%d,\"snapshots\":%d,\"solver_frames\":%d,\"solver_steps\":%d,\"balance_error\":%.9f,\"voxel_payload_bytes\":%d,\"retained_heap_bytes\":%d,\"active_call_ms\":%.3f,\"server_cpu_ms\":%.3f,\"process_cpu_ms\":%.3f,\"metrics\":{",args[0],scene,count,paced?"paced":"geometry",elapsed,readyCells*1000/elapsed,first,percentile(ticks,.95),percentile(ticks,.99),Collections.max(ticks),allocation,gcDelta,gcTimeDelta,world.reads,state.pendingIntervals(),state.iteration(),state.balanceError(),voxelBytes,heap, activeNanos/1e6, (ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime()-serverCpu)/1e6, (((com.sun.management.OperatingSystemMXBean)ManagementFactory.getOperatingSystemMXBean()).getProcessCpuTime()-cpuStart)/1e6);
            String[] names=state.restartMetrics.csvHeader().split(","), values=state.restartMetrics.csvValues().split(",");
            for(int i=0;i<names.length;i++) System.out.print((i==0?"":",")+"\""+names[i]+"\":"+values[i]);
            System.out.print(",\"core_front_scans\":"+state.geometryMetrics.frontScans
                +",\"core_ready_cells\":"+readyCells+",\"core_waiting_cells\":"+(count-readyCells)
                +",\"core_front_ms\":"+state.geometryMetrics.frontNanos/1e6
                +",\"core_jobs\":"+state.geometryMetrics.jobsStarted
                +",\"core_parts\":"+state.geometryMetrics.partCalls
                +",\"core_geometry_calls\":"+state.geometryMetrics.geometryCalls);
            System.out.println("}}");
        }
    }
}
