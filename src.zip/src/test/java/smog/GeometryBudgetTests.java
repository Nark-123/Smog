package smog;

public final class GeometryBudgetTests {
    static void check(boolean ok,String why) { if(!ok) throw new AssertionError(why); }
    public static void main(String[] args) throws Exception {
        GeometryWorkBudget b=new GeometryWorkBudget();
        Object restore=new Object(), background=new Object(), empty=new Object();
        b.begin(100); b.offer(restore,4); b.offer(background,1); b.offer(empty,0);
        check(b.grant(empty,0)==0,"Empty dimension got a share");
        long a=b.grant(restore,4); b.used(restore,a,a);
        long c=b.grant(background,1); b.used(background,c,c);
        check(a==4800000 && c==1200000,"Ready-work weights ignored");
        check(b.grant(restore,4)==0,"Duplicate grant");
        b.end(60000100);
        b.begin(70000100); b.offer(restore,4); b.offer(background,1); b.offer(empty,0);
        check(b.grant(restore,4)<=800000,"MSPT feedback ignored");
        b.used(restore,9000000,9000000);
        check(b.grant(background,1)==0,"All-SMOG overrun did not consume shared pool");
        b.end(71000100);
        int progressed=0;
        // First callback repeatedly overruns. Deficit accounting/floor prevents fixed-order starvation.
        for(int tick=0;tick<60;tick++) {
            long now=100000000L+tick*50000000L;
            b.begin(now); b.offer(restore,4); b.offer(background,1);
            a=b.grant(restore,4);
            b.used(restore,a>0 ? 9000000 : 2000000,a>0 ? 9000000 : 0);
            c=b.grant(background,1);
            if(c>0) progressed++;
            b.used(background,c,c); b.end(now+12000000);
        }
        check(progressed>=3,"Background starved under repeated overruns");
        b.forget(restore); b.forget(background); b.forget(empty);
        try(DimensionState state=new DimensionState(0,FastColdRestartTests.CONFIG,FastColdRestartTests.world())) {
            check(state.geometryWorkWeight()==0,"Idle dimension reported work");
            state.requestBuild(new CellKey(0,0,0,0));
            check(state.geometryWorkWeight()==1,"Ordinary build not runnable");
            state.tick(2000000,20,false,0);
            check(state.nodeCount()==0,"Core ignored adapter cap");
            check(state.gameTicks()==1,"Cap stopped game clock");
        }
        java.nio.file.Path path=OptimisticRestoreTests.cache();
        Checkpoint.Data data=FastColdRestartTests.seed(path,FastColdRestartTests.world());
        SparseTests.World world=FastColdRestartTests.world(); world.ready.clear();
        try(DimensionState state=FastColdRestartTests.restore(data,path,world,true,false)) {
            FastColdRestartTests.drain(state);
            check(state.geometryWorkWeight()==0,"Unavailable checkpoint claimed a runnable budget");
            world.ready.add(FastColdRestartTests.CUBE); state.columnEvent(0,0,false);
            check(state.geometryWorkWeight()==4,"Late checkpoint did not get restore weight");
            FastColdRestartTests.drain(state);
            check(state.geometryWorkWeight()==0,"Sleeping validator claimed work");
        }
        System.out.println("PASS GeometryBudgetTests (ready weights, idle/late dimensions, total SMOG, fairness, cap)");
    }
}
