package smog;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Random;
import java.util.Set;

/** Index oracle, real frame execution, cancellation and dormant checkpoint accounting. */
public final class FrameIndexTests {
    private static int checks;
    private static void check(boolean ok, String why) {
        checks++; if (!ok) throw new AssertionError(why);
    }
    private static long scan(DimensionState s, DimensionState.Cell c) {
        long result = s.steps, ordinal = s.steps;
        for (DimensionState.Frame f : s.frames) {
            ordinal++;
            for (int i = 0; i < f.positions.length; i++)
                if (f.amounts[i] != 0 && f.positions[i].cell().equals(c.key)) result = ordinal;
        }
        return result;
    }
    private static void verify(DimensionState s) {
        for (DimensionState.CubeRecord cube : s.cubes.values())
            for (DimensionState.Cell c : cube.cells) if (c != null)
                check(s.publicationMassBoundary(c) == scan(s, c), "index differs from frame oracle");
    }
    private static void append(DimensionState s, Random random) {
        int count = random.nextInt(6);
        BlockPos[] positions = new BlockPos[count]; double[] amounts = new double[count];
        for (int i = 0; i < count; i++) {
            positions[i] = new BlockPos(0, random.nextInt(24) - 12, random.nextInt(4), i);
            s.cell(positions[i].cell(), true);
            amounts[i] = random.nextBoolean() ? 0 : .125;
        }
        s.addFrame(new DimensionState.Frame(positions, amounts, .25));
        s.emissionWindows++; s.ticks += 20;
    }
    private static void randomQueues() throws Exception {
        Random random = new Random(14291);
        try (DimensionState s = new DimensionState(0, FastColdRestartTests.CONFIG, FastColdRestartTests.world())) {
            s.scheduleParts = 20;
            verify(s);
            for (int i = 0; i < 2801; i++) append(s, random);
            verify(s);
            for (int i = 0; i < 400; i++) {
                if (random.nextBoolean()) append(s, random);
                s.finishPendingPart(20);
                if (i % 7 == 0) { s.graph.cancelStep(); /* simulate unload candidate cancellation */
                    Field f = DimensionState.class.getDeclaredField("candidate"); f.setAccessible(true); f.set(s, null); }
                if (i % 20 == 0) verify(s);
            }
            // Capture serializes immutable frames and ledgers, never the transient index.
            s.graph.cancelStep();
            Checkpoint.Data saved = FastColdRestartTests.snapshot(s);
            java.nio.file.Path dir = Files.createTempDirectory(Paths.get("build"), "frame-index-");
            Checkpoint.write(dir, saved, 0);
            try (DimensionState loaded = DimensionState.load(dir, FastColdRestartTests.world())) {
                verify(loaded);
                check(loaded.frames.size() == s.frames.size(), "checkpoint lost frames");
                check(loaded.pendingMass() == s.pendingMass(), "checkpoint pending ledger");
                while (!loaded.frames.isEmpty()) loaded.finishPendingPart(20);
                verify(loaded);
                check(loaded.indexedContributionCells() == 0, "index retained drained keys");
                check(Math.abs(loaded.balanceError()) < 1e-9, "drained mass ledger");
            }
        }
    }
    private static void dormant() throws Exception {
        System.setProperty("smog.epochAppendRestoreEnabled", "true");
        SparseTests.World w = FastColdRestartTests.world();
        java.nio.file.Path cache = Files.createTempDirectory(Paths.get("build"), "dormant-cache-");
        try (DimensionState s = new DimensionState(0, FastColdRestartTests.CONFIG, w)) {
            s.scheduleParts = 20;
            DimensionState.Cell c = s.cell(new CellKey(0, 0, 0, 0), true);
            c.parked = new DimensionState.MassRecord(new int[512], new int[] {512}, new double[] {.6});
            c.checkpointRestorePending = true; s.injected = .6;
            s.addFrame(new DimensionState.Frame(new BlockPos[] {c.key.block(0)}, new double[] {.4}, 0));
            s.emissionWindows = 1; s.ticks = 20;
            s.finishPendingPart(20);
            // Publish with real build data while solver runs; mass waits for the relevant frame.
            CellBuild b = new CellBuild(s, c);
            while (!b.ready) b.advance();
            s.geometryCache(cache); s.geometryCache.store(b.pack());
            s.geometryCache.flush().get(5, java.util.concurrent.TimeUnit.SECONDS);
            s.graph.cancelStep();
            int policy = s.publishGeometry(c, b.geometry, b.local.seeds, b.boundary, b.self(), b.edges, true);
            s.finishPublicationMass(c, policy);
            w.unload(s, FastColdRestartTests.CUBE);
            Field f = DimensionState.class.getDeclaredField("pendingPublicationMass"); f.setAccessible(true);
            check(((Set<?>)f.get(s)).isEmpty(), "dormant Cell remains in active accounting scan");
            check(c.pendingMassPolicy != 0 && c.parked.total() == .6, "dormant policy/mass lost");
            Checkpoint.Data saved = FastColdRestartTests.snapshot(s);
            try (DimensionState reload = Checkpoint.restore(saved, FastColdRestartTests.world())) {
                reload.finishPendingPart(20); // freeze empty old prefix before reactivation
                reload.geometryCache(cache); reload.resumeReadyCubes();
                for (int i = 0; reload.nodeCount() == 0 && i < 10000; i++) { reload.geometry(2000000); Thread.yield(); }
                check(reload.nodeCount() > 0, "dormant cache reactivation blocked");
                while (!reload.frames.isEmpty()) reload.finishPendingPart(20);
                check(reload.liveMass() == 1, "dormant restart mass=" + reload.liveMass() + " removed=" + reload.removedMass() + " pending=" + reload.pendingMass() + " trapped=" + reload.trappedMass());
                check(reload.removedMass() == 0 && Math.abs(reload.balanceError()) < 1e-9, "dormant ledger");
            }
        }
    }
    public static void main(String[] args) throws Exception {
        randomQueues(); dormant();
        System.out.println("FRAME_INDEX_PASS checks=" + checks);
    }
}
