package smog;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;
import java.io.RandomAccessFile;

/** Indexed record isolation, checksums, config compatibility and cache memory cap. */
public final class GeometryCacheSelectiveTests {
    static void check(boolean value, String why) { if (!value) throw new AssertionError(why); }
    public static void main(String[] args) throws Exception {
        Path path = Files.createTempDirectory(Paths.get("build"), "selective-");
        SparseTests.World world = new SparseTests.World();
        for (int z = 0; z < 4; z++) for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++)
            world.put(new CubeKey(0, x, y, z), SparseTests.air(), 1, 1);
        FastColdRestartTests.options(true, false, false);
        try (DimensionState state = new DimensionState(0, FastColdRestartTests.CONFIG, world)) {
            state.geometryCache(path);
            for (int z = 0; z < 8; z++) for (int y = 0; y < 8; y++) for (int x = 0; x < 8; x++)
                state.queueAddMass(new CellKey(0, x, y, z).block(0), 10);
            FastColdRestartTests.drain(state);
            state.geometryCache.flush().get(15, TimeUnit.SECONDS);
            check(state.restartMetrics.get("cache_write_failures") == 0, "Seed write failure");
        }
        CubeKey first = new CubeKey(0, 0, 0, 0), last = new CubeKey(0, 3, 3, 3);
        Path file = path.resolve("pack-0-0-0.gpk");
        try (GeometryCache cache = new GeometryCache(path, 0, FastColdRestartTests.CONFIG, 1048576)) {
            GeometryCache.Lookup read = cache.request(first).get(5, TimeUnit.SECONDS);
            check(read.status == GeometryCache.Status.OK && read.cells.size() == 8, "Decoded another cube");
            check(read.bytes < Files.size(file), "Read the whole region");
            cache.accept(first, read, new RestartMetrics());
        }
        // An unrelated damaged record is not decoded by a valid demanded cube.
        byte[] original = Files.readAllBytes(file);
        try (RandomAccessFile data = new RandomAccessFile(file.toFile(), "rw")) {
            data.seek(data.length() - 1); int value = data.read();
            data.seek(data.length() - 1); data.write(value ^ 1);
        }
        try (GeometryCache cache = new GeometryCache(path, 0, FastColdRestartTests.CONFIG, 1048576)) {
            check(cache.request(first).get(5, TimeUnit.SECONDS).status == GeometryCache.Status.OK,
                "Unrelated record decoded on critical path");
            check(cache.request(last).get(5, TimeUnit.SECONDS).status == GeometryCache.Status.CORRUPT,
                "Damaged demanded record accepted");
        }
        Files.write(file, original);
        original[48] ^= 1;
        Files.write(file, original);
        try (GeometryCache cache = new GeometryCache(path, 0, FastColdRestartTests.CONFIG, 1048576)) {
            check(cache.request(first).get(5, TimeUnit.SECONDS).status == GeometryCache.Status.CORRUPT,
                "Invalid index accepted");
        }
        original[48] ^= 1;
        Files.write(file, original);
        try (GeometryCache cache = new GeometryCache(path, 0, FastColdRestartTests.CONFIG, 256)) {
            RestartMetrics metrics = new RestartMetrics();
            cache.accept(first, cache.request(first).get(5, TimeUnit.SECONDS), metrics);
            check(metrics.get("cache_memory_bytes") <= 256, "Cache exceeded memory limit");
        }
        System.out.println("PASS GeometryCacheSelectiveTests (64 cubes, 512 cells, record/index corruption, cap)");
    }
}
