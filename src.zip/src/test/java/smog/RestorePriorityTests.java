package smog;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/** A mass frontier into ready unsaved air must not starve the saved-section index. */
public final class RestorePriorityTests {
    public static void main(String[] args) throws Exception {
        RestoreBenchmark.setup("open",1024);
        byte[][] templates=RestoreBenchmark.templates();
        Path root=Files.createTempDirectory(Paths.get("build"),"priority-");
        Path directory=RestoreBenchmark.data(root,templates);
        try(DimensionState state=Checkpoint.restore(RestoreBenchmark.checkpoint(templates),new RestoreBenchmark.World())) {
            state.geometryCache(directory); state.resumeReadyCubes();
            for(int tick=0;tick<500 && state.restartMetrics.get("restart_cells_published")<1024;tick++) {
                state.tick(2000000,20,false,4000000);
                Thread.sleep(1);
            }
            if(state.restartMetrics.get("restart_cells_published")!=1024)
                throw new AssertionError("Unsaved expansion starved saved restoration: published="
                    +state.restartMetrics.get("restart_cells_published"));
            // A warm restore may finish before the first 20-tick emission interval.
            // Prove solver progress independently of how quickly restoration completes.
            for (int tick=0; tick<40 && state.iteration()==0; tick++) state.tick(2000000,20,false,4000000);
            if(state.iteration()==0) throw new AssertionError("Restoration paused law4");
            FastColdRestartTests.near(state.balanceError(),0,"Restore/expansion ledger");
        }
        System.out.println("PASS RestorePriorityTests (1024 saved cells, ready unsaved halo, live solver)");
    }
}
