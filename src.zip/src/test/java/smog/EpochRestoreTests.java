package smog;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.SortedMap;
import java.util.concurrent.TimeUnit;

/** Real checkpoint/cache/DimensionState integration with a synthetic readiness-only world. */
public final class EpochRestoreTests {
    private static int checks;
    private static Path directory;
    private static byte[][] templates;
    private static final class SavedWorld extends RestoreBenchmark.World {
        public boolean isReady(CubeKey key) {
            return key.dimension == 0 && key.x >= 0 && key.x < RestoreBenchmark.nx
                && key.y >= 0 && key.y < RestoreBenchmark.ny && key.z >= 0 && key.z < RestoreBenchmark.nz;
        }
    }
    private static final class SwitchWorld extends RestoreBenchmark.World {
        boolean available = true;
        public boolean isReady(CubeKey key) {
            return super.isReady(key) && (available || !key.equals(FastColdRestartTests.CUBE));
        }
    }
    private static void check(boolean ok, String why) { checks++; if (!ok) throw new AssertionError(why); }
    private static void near(double actual, double expected, String why) {
        check(Math.abs(actual - expected) <= 2e-10 * Math.max(1, Math.abs(expected)), why + ": " + actual + " != " + expected);
    }
    private static Checkpoint.Data data() throws Exception { return RestoreBenchmark.checkpoint(templates); }
    private static DimensionState restore(Checkpoint.Data data, WorldSnapshotProvider world, boolean epoch) {
        System.setProperty("smog.epochAppendRestoreEnabled", "" + epoch);
        System.setProperty("smog.fastRestoreEnabled", "true");
        DimensionState s = Checkpoint.restore(data, world);
        s.geometryCache(directory); s.resumeReadyCubes(); return s;
    }
    private static void frame(DimensionState s, BlockPos p, double mass) {
        s.ticks += 20;
        s.emissionWindows++;
        s.addFrame(new DimensionState.Frame(p == null ? new BlockPos[0] : new BlockPos[] {p},
            p == null ? new double[0] : new double[] {mass}, 0));
        check(!s.finishPendingPart(20) && s.graph.isStepInProgress(), "did not begin epoch");
    }
    private static void publish(DimensionState s, int cells) {
        long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
        // Exercise the restore plan in isolation: new CellBuild expansion is now eligible
        // mid-step too, and would deliberately change this fixture's idle replay topology.
        while (s.restartMetrics.get("restart_cells_published") < cells && System.nanoTime() < end) {
            if (!s.epochRestoreEnabled()) { s.geometry(2000000); Thread.yield(); continue; }
            DimensionState.Cell next = null;
            for (DimensionState.CubeRecord cube : s.cubes.values()) for (DimensionState.Cell c : cube.cells)
                if (c != null && c.checkpointRestorePending && c.geometry == null && !c.building
                    && s.provider.isReady(c.cube.key)) { next = c; break; }
            check(next != null, "no eligible saved candidate");
            EpochRestorePlan plan = new EpochRestorePlan(s, next);
            while (plan.advance() != 0 && System.nanoTime() < end) Thread.yield();
        }
        check(s.restartMetrics.get("restart_cells_published") == cells, "restore blocked behind epoch");
    }
    private static void finish(DimensionState s) {
        for (int i = 0; s.graph.isStepInProgress() && i < 20; i++) s.finishPendingPart(20);
        check(!s.graph.isStepInProgress(), "epoch did not end");
        near(s.balanceError(), 0, "mass ledger");
    }
    private static void topologyAndSwitches() throws Exception {
        SortedMap<String, Double> reference;
        try (DimensionState s = restore(data(), new SavedWorld(), false)) {
            FastColdRestartTests.drain(s); reference = s.topology();
        }
        System.setProperty("smog.epochMicroCells", "3");
        try (DimensionState s = restore(data(), new SavedWorld(), true)) {
            frame(s, null, 0); publish(s, 512);
            check(s.iteration() == 0, "restore advanced physics itself");
            check(s.restartMetrics.get("epoch_append_cells") == 512, "not all published between portions");
            check(s.restartMetrics.get("epoch_append_batches") >= 171, "micro-cell cap ignored");
            check(s.topology().equals(reference), "region/micro topology or duplicate contacts, reference="
                + reference.size() + " actual=" + s.topology().size());
            near(s.liveMass(), 5120, "visible appended mass");
            finish(s);
            near(s.liveMass(), 5120, "new nodes leaked into old epoch");
            check(s.restartMetrics.get("epoch_fallback_cells") == 0, "valid cache fell back");
        } finally { System.clearProperty("smog.epochMicroCells"); }
        try (DimensionState s = restore(data(), new RestoreBenchmark.World(), false)) {
            frame(s, null, 0);
            for (int i = 0; i < 100; i++) s.geometry(1000000);
            check(s.nodeCount() == 0, "legacy flag bypassed global safe boundary");
            finish(s); publish(s, 512); near(s.balanceError(), 0, "legacy ledger");
        }
    }
    private static Checkpoint.Data one(double mass, boolean remap) throws Exception {
        Checkpoint.Data d = data();
        Checkpoint.CellData c = d.cells.get(0);
        d.cells.clear(); d.cells.add(c); d.injected = mass;
        int[] labels = new int[512];
        if (remap) for (int p = 256; p < 512; p++) labels[p] = 1;
        c.mass = new DimensionState.MassRecord(labels, remap ? new int[] {256, 256} : new int[] {512},
            remap ? new double[] {mass * .5, mass - mass * .5} : new double[] {mass});
        return d;
    }
    private static void epsilonAndEvents() throws Exception {
        for (boolean remap : new boolean[] {false, true})
            for (double mass : new double[] {0, Double.MIN_VALUE, .6, Math.nextDown(1.0), 1,
                Math.nextUp(1.0), 100, 1e15}) {
                Checkpoint.Data d = one(mass, remap);
                try (DimensionState s = restore(d, new RestoreBenchmark.World(), true)) {
                    frame(s, null, 0); publish(s, 1);
                    near(s.liveMass(), mass, "epsilon ran before final mass");
                    finish(s);
                    near(s.liveMass(), mass < 1 ? 0 : mass, "epsilon threshold/remap");
                    near(s.removedMass(), mass > 0 && mass < 1 ? mass : 0, "epsilon ledger");
                }
            }
        Checkpoint.Data d = one(.4, false);
        d.cells.get(0).trapped.put(0, .2); // Already injected authoritative mass.
        d.injected += .2;
        d.cells.get(0).waiting.put(0, .1);
        DimensionState.Event event = new DimensionState.Event(); event.add = .1;
        d.cells.get(0).events.put(0, event);
        try (DimensionState s = restore(d, new RestoreBenchmark.World(), true)) {
            frame(s, d.cells.get(0).key.block(0), .2);
            publish(s, 1);
            near(s.liveMass(), .6, "private remap/trapped contribution");
            check(s.pendingMass() > 0 && s.removedMass() == 0, "pending events discarded");
            finish(s);
            near(s.liveMass(), 1, "waiting/trapped/frame/events must merge before epsilon");
            near(s.removedMass(), 0, "exactly one was pruned");
            check(s.pendingMass() == 0, "events replayed or retained");
        }
    }
    private static void unloadAndSave() throws Exception {
        SwitchWorld liveWorld = new SwitchWorld();
        Checkpoint.Data d = one(.6, false);
        try (DimensionState s = restore(d, liveWorld, true)) {
            frame(s, d.cells.get(0).key.block(0), .4); publish(s, 1);
            liveWorld.available = false;
            s.onWorldCubeUnloading(FastColdRestartTests.CUBE, 1);
            near(s.parkedMass(), .6, "cancel/unload appended mass");
            check(s.pendingIntervals() == 1 && !s.graph.isStepInProgress(), "frame lost on cancel");
            liveWorld.available = true;
            s.onWorldCubeAvailable(FastColdRestartTests.CUBE);
            int slotsBeforeReload = s.graph.allocatedNodeSlots();
            EpochRestorePlan reload = new EpochRestorePlan(s, s.cell(d.cells.get(0).key, false));
            long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
            int progress = 1;
            while (progress != 0 && System.nanoTime() < end) progress = reload.advance();
            check(s.cell(d.cells.get(0).key, false).geometry != null, "same JVM reload failed");
            check(s.graph.allocatedNodeSlots() == slotsBeforeReload, "idle reload did not reuse free node IDs");
            near(s.liveMass(), .6, "replay frame epsilon was applied early");
            Path saveDir = Files.createTempDirectory(Paths.get("build"), "epoch-save-");
            java.util.concurrent.CompletableFuture<Path> save = s.requestSave(saveDir);
            for (int i = 0; !save.isDone() && i < 10000; i++) {
                s.finishPendingPart(20); s.geometry(1000000); Thread.yield();
            }
            save.get(5, TimeUnit.SECONDS);
            near(s.liveMass(), 1, "source frame applied twice/lost");
            near(s.restartMetrics.get("restore_mass_ratio"), 1, "cancel/reload lost checkpoint progress metric");
            try (DimensionState loaded = DimensionState.load(saveDir, liveWorld)) {
                near(loaded.parkedMass(), 1, "SAFE CUT lost final publication mass");
                near(loaded.balanceError(), 0, "save/load ledger");
            }
        }
        // Unpublished plan loses availability before append: no graph mutation, parked untouched.
        SparseTests.World w = FastColdRestartTests.world();
        d = one(10, false);
        try (DimensionState s = restore(d, w, true)) {
            EpochRestorePlan plan = new EpochRestorePlan(s, s.cell(d.cells.get(0).key, false));
            Field stage = EpochRestorePlan.class.getDeclaredField("stage"); stage.setAccessible(true);
            long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
            while (stage.getInt(plan) < 3 && System.nanoTime() < end) plan.advance();
            w.unload(s, FastColdRestartTests.CUBE);
            while (plan.advance() != 0) {}
            check(s.nodeCount() == 0, "unavailable plan committed");
            near(s.parkedMass(), 10, "abandoned plan mutated authoritative mass");
            near(s.balanceError(), 0, "abandon ledger");
        }
    }
    private static void failStop() throws Exception {
        Checkpoint.Data d = data(); d.cells.subList(2, d.cells.size()).clear(); d.injected = 20;
        try (DimensionState s = restore(d, new RestoreBenchmark.World(), true)) {
            EpochRestorePlan plan = new EpochRestorePlan(s, s.cell(d.cells.get(0).key, false));
            prepare(plan);
            Field entries = EpochRestorePlan.class.getDeclaredField("entries"); entries.setAccessible(true);
            Object second = ((java.util.List<?>)entries.get(plan)).get(1);
            Field packField = EpochAppendBatch.Item.class.getDeclaredField("pack"); packField.setAccessible(true);
            GeometryPack pack = (GeometryPack)packField.get(second);
            Field seeds = GeometryPack.class.getDeclaredField("seeds"); seeds.setAccessible(true);
            seeds.set(pack, new int[0]); // Inject an unexpected failure after the first cell mutates.
            boolean failed = false;
            try { while (plan.advance() != 0) {} } catch (ArrayIndexOutOfBoundsException expected) { failed = true; }
            check(failed && s.nodeCount() > 0 && s.nodeCount() < 2,
                "fixture did not interrupt a partially mutated commit: failed=" + failed + " nodes=" + s.nodeCount());
            boolean refused = false;
            try { s.tick(1000000); } catch (IllegalStateException expected) { refused = true; }
            check(refused, "failed dimension resumed");
            refused = false;
            try { new Checkpoint.Capture(s); } catch (IllegalStateException expected) { refused = true; }
            check(refused, "failed dimension was saved");
        }
    }
    private static void prepare(EpochRestorePlan plan) throws Exception {
        Field stage = EpochRestorePlan.class.getDeclaredField("stage"); stage.setAccessible(true);
        long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
        while (stage.getInt(plan) < 3 && System.nanoTime() < end) { plan.advance(); Thread.yield(); }
        check(stage.getInt(plan) == 3, "private preparation timed out");
    }
    private static void contactsAndInvalidation() throws Exception {
        Checkpoint.Data d = data();
        d.cells.removeIf(c -> !(c.key.y == 0 && c.key.z == 0 && (c.key.x == 1 || c.key.x == 2)));
        d.injected = 20;
        try (DimensionState s = restore(d, new RestoreBenchmark.World(), true)) {
            frame(s, null, 0);
            EpochRestorePlan first = new EpochRestorePlan(s, s.cell(d.cells.get(0).key, false)); prepare(first);
            EpochRestorePlan second = new EpochRestorePlan(s, s.cell(d.cells.get(1).key, false)); prepare(second);
            while (second.advance() != 0) {}
            while (first.advance() != 0) {}
            check(s.nodeCount() == 2 && s.edgeCount() == 1, "external refresh duplicated or missed contact");
            finish(s); near(s.liveMass(), 20, "contact refresh mass");
        }
        try (DimensionState s = restore(one(10, false), new RestoreBenchmark.World(), true)) {
            DimensionState.Cell cell = s.cubes.values().iterator().next().cells[0];
            EpochRestorePlan plan = new EpochRestorePlan(s, cell); prepare(plan);
            s.invalidateRegion(cell.key.block(0), cell.key.block(0));
            while (plan.advance() != 0) {}
            check(s.nodeCount() == 0, "stale preparation ticket published");
            near(s.parkedMass(), 10, "edit while preparing lost mass");
        }
        SparseTests.World world = OptimisticRestoreTests.halo();
        try (DimensionState s = restore(one(10, false), world, true)) {
            frame(s, null, 0); publish(s, 1);
            world.change(FastColdRestartTests.CUBE, new byte[4096]);
            s.validator.advance(TimeUnit.SECONDS.toNanos(1));
            check(s.restartMetrics.get("validation_dirty") > 0, "optimistic cache was not invalidated");
            check(s.graph.isStepInProgress() && s.nodeCount() == 1, "validation destroyed a live epoch");
            finish(s); FastColdRestartTests.drain(s);
            near(s.trappedMass(), 10, "invalidated solid-world remap"); near(s.balanceError(), 0, "invalidation ledger");
        }
    }
    private static void industrialSource() throws Exception {
        Checkpoint.Data d = one(10, false);
        BlockPos position = d.cells.get(0).key.block(0);
        d.sources.add(new DimensionState.Source(position, 20, 0));
        try (DimensionState s = restore(d, new RestoreBenchmark.World(), true)) {
            s.onWorldCubeAvailable(position.cell().cube());
            for (int tick = 0; tick < 20; tick++) s.tick(0, 20, false, 0);
            check(s.pendingIntervals() == 1, "industrial frame did not accumulate");
            s.finishPendingPart(20); // The candidate source still points to no runtime node.
            publish(s, 1);
            check(s.sources.get(position).node >= 0, "publication did not rebind source");
            finish(s);
            near(s.liveMass(), 30, "new binding changed an already captured source frame");
            near(s.injectedMass(), 30, "industrial frame injected twice or dropped");
        }
    }
    private static void idlePublicationFrames() throws Exception {
        for (boolean sameCell : new boolean[] {false, true}) {
            Checkpoint.Data d = one(.6, false);
            BlockPos p = d.cells.get(0).key.block(0);
            try (DimensionState s = restore(d, new RestoreBenchmark.World(), true)) {
                s.addFrame(new DimensionState.Frame(new BlockPos[] {sameCell ? p : p.offset(8, 0, 0)},
                    new double[] {.4}, 0));
                EpochRestorePlan plan = new EpochRestorePlan(s, s.cell(p.cell(), false)); prepare(plan);
                while (plan.advance() != 0) {}
                near(s.liveMass(), sameCell ? .6 : 0, "epsilon waited for an unrelated frame");
                if (sameCell) {
                    for (int part = 0; part < 20; part++) s.finishPendingPart(20);
                    near(s.liveMass(), 1, "idle queued source did not merge before epsilon");
                    near(s.balanceError(), 0, "idle queued source ledger");
                }
            }
        }
        Checkpoint.Data d = one(10, false);
        try (DimensionState s = restore(d, new RestoreBenchmark.World(), true)) {
            s.addFrame(new DimensionState.Frame(new BlockPos[0], new double[0], 0));
            EpochRestorePlan plan = new EpochRestorePlan(s, s.cell(d.cells.get(0).key, false)); prepare(plan);
            while (plan.advance() != 0) {}
            int id = s.cell(d.cells.get(0).key, false).geometry.ids[0];
            s.graph.sparseBoundary(id, 100);
            for (int part = 0; part < 20; part++) s.finishPendingPart(20);
            check(s.liveMass() > 0 && s.liveMass() < 1, "sink fixture did not cross epsilon");
            near(s.removedMass(), 0, "an empty frame postponed publication epsilon until after physical sinks");
            near(s.balanceError(), 0, "idle sink ledger");
        }
    }
    private static void localFallback() throws Exception {
        Field stage = EpochRestorePlan.class.getDeclaredField("stage"); stage.setAccessible(true);
        for (int target : new int[] {0, 3, 7}) for (int phase = 0; phase <= 3; phase++) {
            Checkpoint.Data d = data(); d.cells.subList(8, d.cells.size()).clear(); d.injected = 80;
            try (DimensionState s = restore(d, new RestoreBenchmark.World(), true)) {
                DimensionState.Cell bad = s.cell(d.cells.get(target).key, false);
                EpochRestorePlan plan = new EpochRestorePlan(s, bad);
                for (int units = 0; stage.getInt(plan) < phase && units < 100000; units++) { plan.advance(); Thread.yield(); }
                bad.ticket++; // one stale candidate, not an artificial change to all halo snapshots
                for (int units = 0; units < 100000 && plan.advance() != 0; units++) Thread.yield();
                for (Checkpoint.CellData saved : d.cells) {
                    DimensionState.Cell c = s.cell(saved.key, false);
                    check(c == bad || c.geometry != null || !c.cacheAttempted,
                        "valid neighbor forced to fallback phase=" + phase + " slot=" + target);
                }
                FastColdRestartTests.drain(s);
                check(s.restartMetrics.get("fast_restore_cells") == 7, "one stale entry lost valid fast cells");
                near(s.balanceError(), 0, "localized fallback ledger");
            }
        }
        Checkpoint.Data d = one(10, false);
        try (DimensionState s = restore(d, new RestoreBenchmark.World(), true)) {
            EpochRestorePlan plan = new EpochRestorePlan(s, s.cell(d.cells.get(0).key, false)); prepare(plan);
            check(plan.advance() == 1 && s.restartMetrics.get("capacity_retries") > 0,
                "capacity preparation did not yield");
            check(s.restartMetrics.get("preflight_rechecks") == 0, "preflight repeated while reserving");
            while (plan.advance() != 0) {}
            check(s.restartMetrics.get("preflight_rechecks") == 1, "stable append checked more than once");
        }
    }

    private static void unsupportedLawFallback() throws Exception {
        Checkpoint.Data d = one(10, false);
        try (DimensionState s = restore(d, new RestoreBenchmark.World(), true)) {
            EpochRestorePlan plan = new EpochRestorePlan(s, s.cell(d.cells.get(0).key, false)); prepare(plan);
            s.graph.setLaw(SmogConfig.LINEAR);
            check(plan.runnable(), "unsupported-law fallback received no runnable budget");
            check(plan.advance() == 0 && s.nodeCount() == 0, "law change stranded an epoch-only plan");
            near(s.parkedMass(), 10, "law fallback mutated parked mass");
            FastColdRestartTests.drain(s);
            near(s.liveMass(), 10, "unsupported law did not use ordinary safe restore");
            near(s.balanceError(), 0, "law fallback ledger");
        }
    }
    public static void main(String[] args) throws Exception {
        RestoreBenchmark.setup("open", 512);
        templates = RestoreBenchmark.templates();
        directory = RestoreBenchmark.data(Files.createTempDirectory(Paths.get("build"), "epoch-data-"), templates);
        topologyAndSwitches(); epsilonAndEvents(); unloadAndSave(); industrialSource(); idlePublicationFrames(); localFallback(); unsupportedLawFallback(); failStop();
        // Invalidation intentionally rewrites the derived cache to the changed world, so run it last.
        contactsAndInvalidation();
        System.out.println("EpochRestoreTests OK checks=" + checks + " (synthetic world; no GTNH claim)");
    }
}
