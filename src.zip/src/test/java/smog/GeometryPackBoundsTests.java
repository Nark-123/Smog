package smog;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

public final class GeometryPackBoundsTests {
    static int checks;
    static byte[] encode(GeometryPack pack) throws Exception {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream(); pack.write(new DataOutputStream(bytes));
        return bytes.toByteArray();
    }
    static void reject(byte[] bytes) throws Exception {
        checks++;
        try { GeometryPack.read(new DataInputStream(new ByteArrayInputStream(bytes)),0); }
        catch(IOException expected) { return; }
        throw new AssertionError("Structurally invalid pack accepted");
    }
    public static void main(String[] args) throws Exception {
        Path path=Files.createTempDirectory(Paths.get("build"),"pack-bounds-");
        FastColdRestartTests.seed(path,FastColdRestartTests.world());
        GeometryPack pack;
        try(GeometryCache cache=new GeometryCache(path,0,FastColdRestartTests.CONFIG,1048576)) {
            pack=cache.request(FastColdRestartTests.CUBE).get(5,TimeUnit.SECONDS).cells.values().iterator().next();
        }
        byte[] original=encode(pack), bad=original.clone();
        ByteBuffer.wrap(bad).putShort(14,(short)-2); reject(bad);
        bad=original.clone(); ByteBuffer.wrap(bad).putShort(14,(short)pack.volumes.length); reject(bad);
        int node=14+1536;
        bad=original.clone(); ByteBuffer.wrap(bad).putShort(node,(short)511); reject(bad);
        bad=original.clone(); ByteBuffer.wrap(bad).putShort(node+2,(short)512); reject(bad);
        bad=original.clone(); ByteBuffer.wrap(bad).putDouble(node+4,Double.NaN); reject(bad);
        bad=original.clone(); ByteBuffer.wrap(bad).putDouble(node+4,6145); reject(bad);
        int contacts=node+12*pack.volumes.length;
        bad=original.clone(); ByteBuffer.wrap(bad).putInt(contacts,-1); reject(bad);
        bad=original.clone(); ByteBuffer.wrap(bad).putInt(contacts,1345); reject(bad);
        for(int i=0;i<pack.dependencies.length;i++) if(pack.dependencies[i].equals(pack.key.cube())) {
            pack.fingerprints[i]=null; reject(encode(pack));
        }
        System.out.println("PASS GeometryPackBoundsTests checks="+checks);
    }
}
