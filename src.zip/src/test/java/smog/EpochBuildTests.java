package smog;

import java.lang.reflect.Field;
import java.util.ArrayDeque;
import java.util.SortedMap;

/** Cache misses use the same append contract; destructive builds remain on safe cuts. */
public final class EpochBuildTests {
    private static int checks;
    private static void check(boolean ok, String why) { checks++; if (!ok) throw new AssertionError(why); }
    private static void near(double a, double b, String why) {
        check(Math.abs(a - b) <= 1e-10 * Math.max(1, Math.abs(b)), why + ": " + a + " != " + b);
    }
    private static DimensionState state(boolean epoch, WorldSnapshotProvider world) {
        System.setProperty("smog.epochAppendRestoreEnabled", "" + epoch);
        System.setProperty("smog.geometryCacheEnabled", "false");
        return new DimensionState(0, FastColdRestartTests.CONFIG, world);
    }
    private static void frame(DimensionState s) {
        s.scheduleParts = 20; s.ticks += 20; s.emissionWindows++;
        s.addFrame(new DimensionState.Frame(new BlockPos[0], new double[0], 0));
    }
    private static CellBuild build(DimensionState s, CellKey key) {
        DimensionState.Cell c = s.cell(key, true); c.building = true;
        CellBuild b = new CellBuild(s, c); while (!b.ready) b.advance(); return b;
    }
    private static void append(CellBuild b) {
        EpochBuildAppend a = new EpochBuildAppend(b);
        for (int i = 0; i < 10000; i++) {
            int result = a.advance();
            if (result == 0) { b.cell.building = false; return; }
            check(result > 0, "valid private build rejected");
            while (!b.ready) b.advance(); a.refreshed();
        }
        throw new AssertionError("append did not finish");
    }
    private static void portions() throws Exception {
        for (int insertion = 1; insertion <= 20; insertion++) {
            try (DimensionState actual = state(true, FastColdRestartTests.world());
                 DimensionState reference = state(false, FastColdRestartTests.world())) {
                CellKey old = new CellKey(0, 0, 0, 0), added = new CellKey(0, 1, 0, 0);
                CellBuild a = build(actual, old), r = build(reference, old);
                actual.publishGeometry(a.cell, a.geometry, a.local.seeds, a.boundary, a.self(), a.edges, true);
                reference.publishGeometry(r.cell, r.geometry, r.local.seeds, r.boundary, r.self(), r.edges, true);
                actual.graph.addNodeMass(a.geometry.ids[0], 25); actual.injected = 25;
                reference.graph.addNodeMass(r.geometry.ids[0], 25); reference.injected = 25;
                frame(actual); frame(reference);
                for (int i = 0; i < insertion; i++) { actual.finishPendingPart(20); reference.finishPendingPart(20); }
                CellBuild fresh = build(actual, added); append(fresh);
                for (int i = insertion; i < 20; i++) { actual.finishPendingPart(20); reference.finishPendingPart(20); }
                CellBuild later = build(reference, added);
                reference.publishGeometry(later.cell, later.geometry, later.local.seeds, later.boundary, later.self(), later.edges, true);
                check(Double.doubleToLongBits(actual.graph.nodeMass(a.geometry.ids[0]))
                    == Double.doubleToLongBits(reference.graph.nodeMass(r.geometry.ids[0])), "old law4 prefix changed part=" + insertion);
                check(actual.topology().equals(reference.topology()), "duplicate/missing build edges");
                frame(actual); frame(reference);
                for (int i = 0; i < 20; i++) { actual.finishPendingPart(20); reference.finishPendingPart(20); }
                near(actual.liveMass(), reference.liveMass(), "next epoch mass"); near(actual.balanceError(), 0, "append ledger");
            }
        }
    }
    @SuppressWarnings("unchecked")
    private static void mixedBacklog() throws Exception {
        RestoreBenchmark.setup("open", 100000);
        try (DimensionState s = state(true, new RestoreBenchmark.World())) {
            // A destructive head waiting for the solver cannot block 100k new queued tasks.
            Field f = DimensionState.class.getDeclaredField("prepared"); f.setAccessible(true);
            ArrayDeque<CellBuild> replacements = (ArrayDeque<CellBuild>)f.get(s);
            CellBuild old = null;
            int replacementCount = s.preparedLimit() / 2;
            for (int i = 0; i < replacementCount; i++) {
                CellBuild active = build(s, new CellKey(0, i % 32, i / 32, 0));
                s.publishGeometry(active.cell, active.geometry, active.local.seeds, active.boundary, active.self(), active.edges, true);
                active.cell.building = false;
                replacements.add(build(s, active.cell.key));
                if (old == null) old = active;
            }
            Field af = DimensionState.class.getDeclaredField("appendPrepared"); af.setAccessible(true);
            ArrayDeque<CellBuild> appends = (ArrayDeque<CellBuild>)af.get(s);
            for (int i = replacementCount; i < s.preparedLimit() - 1; i++)
                appends.add(build(s, new CellKey(0, i % 32, i / 32, 0)));
            check(s.geometryQueues()[2] == s.preparedLimit() - 1, "fixture did not reach prepared cap");
            DimensionState.Geometry original = old.cell.geometry;
            for (int i = 1; i <= 100064; i++) s.requestBuild(new CellKey(0, i % 32, i / 32 % 32, i / 1024));
            check(s.geometryQueues()[0] + s.geometryQueues()[2] >= 100000, "fixture backlog too small");
            // Model an old cache-claim queue reference, then a later world edit.
            CellBuild escaped = build(s, new CellKey(0, 0, 3, 0));
            s.publishGeometry(escaped.cell, escaped.geometry, escaped.local.seeds, escaped.boundary, escaped.self(), escaped.edges, true);
            escaped.cell.building = false; s.validationDirty(escaped.cell);
            Field bf = DimensionState.class.getDeclaredField("builds"); bf.setAccessible(true);
            ((ArrayDeque<DimensionState.Cell>)bf.get(s)).addFirst(escaped.cell);
            long rebuilds = s.geometryMetrics.rebuildJobs;
            s.setSourceRate(old.cell.key.block(0), 2);
            for (int tick = 0; tick < 20; tick++) s.tick(0, 20, false, 0);
            s.finishPendingPart(20);
            for (int tick = 0; tick < 40; tick++) s.geometry(2000000); // fixed 2 ms, no restore boost
            check(s.restartMetrics.get("fallback_epoch_appended_cells") > 0, "new builds starved behind replacement");
            check(old.cell.geometry == original, "replacement published mid-step");
            check(s.geometryMetrics.rebuildJobs == rebuilds, "stale new-queue reference bypassed replacement backpressure");
            check(s.graph.isStepInProgress() && s.iteration() == 0, "build path advanced/cancelled solver");
            for (int i = 1; i < 20; i++) s.finishPendingPart(20);
            for (int i = 0; i < 100 && old.cell.geometry == original; i++) s.geometry(2000000);
            check(old.cell.geometry != original, "replacement starved at safe cut");
            check(s.geometryQueues()[2] <= s.preparedLimit(), "prepared backpressure overflow");
            near(s.balanceError(), 0, "mixed queue ledger");
        }
    }
    private static void staleAndCancel() throws Exception {
        SparseTests.World w = FastColdRestartTests.world();
        try (DimensionState s = state(true, w)) {
            CellBuild b = build(s, new CellKey(0, 0, 0, 0));
            EpochBuildAppend a = new EpochBuildAppend(b); w.unload(s, FastColdRestartTests.CUBE);
            int result = 1; for (int i = 0; result > 0 && i < 100; i++) result = a.advance();
            check(result < 0 && s.nodeCount() == 0, "unloaded build committed");
        }
        w = FastColdRestartTests.world();
        try (DimensionState s = state(true, w)) {
            DimensionState.Cell c = s.cell(new CellKey(0, 0, 0, 0), true);
            c.parked = new DimensionState.MassRecord(new int[512], new int[] {512}, new double[] {.6});
            c.checkpointRestorePending = true; s.injected = .6;
            s.scheduleParts = 20; s.ticks = 20; s.emissionWindows = 1;
            s.addFrame(new DimensionState.Frame(new BlockPos[] {c.key.block(0)}, new double[] {.4}, 0));
            s.finishPendingPart(20);
            append(build(s, c.key)); near(s.liveMass(), .6, "early build epsilon");
            w.unload(s, FastColdRestartTests.CUBE);
            near(s.parkedMass(), .6, "append unload parked");
            check(s.pendingIntervals() == 1, "unload lost frame");
            Checkpoint.Data saved = FastColdRestartTests.snapshot(s);
            try (DimensionState reloaded = Checkpoint.restore(saved, FastColdRestartTests.world())) {
                reloaded.finishPendingPart(20); reloaded.resumeReadyCubes();
                for (int i = 0; reloaded.nodeCount() == 0 && i < 1000; i++) reloaded.geometry(2000000);
                for (int i = 1; i < 20; i++) reloaded.finishPendingPart(20);
                near(reloaded.liveMass(), 1, "cold build restart final contributions");
                near(reloaded.balanceError(), 0, "cold build restart ledger");
            }
        }
    }
    private static void geometryScenes() throws Exception {
        for (String scene : new String[] {"open", "rooms", "dense", "atmosphere"}) {
            RestoreBenchmark.setup(scene, 64);
            Checkpoint.Data d = RestoreBenchmark.checkpoint(RestoreBenchmark.templates());
            d.sources.add(new DimensionState.Source(d.cells.get(0).key.block(0), 0, 0));
            SortedMap<String, Double> topology;
            double[] samples = new double[64];
            System.setProperty("smog.epochAppendRestoreEnabled", "false");
            try (DimensionState reference = Checkpoint.restore(d, new RestoreBenchmark.World())) {
                for (Checkpoint.CellData saved : d.cells) {
                    CellBuild b = build(reference, saved.key);
                    int policy = reference.publishGeometry(b.cell, b.geometry, b.local.seeds, b.boundary, b.self(), b.edges, true);
                    reference.applyEvents(); reference.finishPublicationMass(b.cell, policy);
                }
                topology = reference.topology();
                frame(reference);
                for (int i = 0; i < 20; i++) reference.finishPendingPart(20);
                for (int i = 0; i < 64; i++) samples[i] = reference.sample(d.cells.get(i).key.block(0));
            }
            System.setProperty("smog.epochAppendRestoreEnabled", "true");
            try (DimensionState actual = Checkpoint.restore(d, new RestoreBenchmark.World())) {
                frame(actual); actual.finishPendingPart(20);
                for (Checkpoint.CellData saved : d.cells) append(build(actual, saved.key));
                check(actual.topology().equals(topology), "cold build topology " + scene);
                check(actual.sources.values().iterator().next().node >= 0 || scene.equals("dense"), "source not rebound");
                for (int i = 1; i < 20; i++) actual.finishPendingPart(20);
                frame(actual);
                for (int i = 0; i < 20; i++) actual.finishPendingPart(20);
                for (int i = 0; i < 64; i++) near(actual.sample(d.cells.get(i).key.block(0)), samples[i], "cold next-step " + scene);
                near(actual.balanceError(), 0, "cold scene ledger " + scene);
            }
        }
    }

    public static void main(String[] args) throws Exception {
        portions(); mixedBacklog(); staleAndCancel(); geometryScenes();
        System.out.println("EPOCH_BUILD_PASS checks=" + checks);
    }
}
