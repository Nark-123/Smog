package smog;

/** Positive dependency reuse is tied to exact fingerprints and current epoch/revision. */
public final class ValidationReuseTests {
    private static int checks;
    private static void check(boolean ok, String why) { checks++; if (!ok) throw new AssertionError(why); }
    private static DimensionState.Cell task(DimensionState s, int slot, byte[] expected) {
        DimensionState.Cell c = s.cell(new CellKey(0, slot & 1, slot >> 1 & 1, slot >> 2 & 1), true);
        DimensionState.Geometry g = new DimensionState.Geometry();
        g.ids = new int[0]; g.dependencies = new CubeKey[] {FastColdRestartTests.CUBE};
        g.verification = DimensionState.GeometryState.UNVERIFIED; c.geometry = g;
        s.validator.add(c, g, new byte[][] {expected}); return c;
    }
    private static void drain(DimensionState s) {
        for (int i = 0; s.validator.runnable() && i < 100; i++) s.validator.advance(1000000);
        check(!s.validator.runnable(), "validation did not finish its ready work");
    }
    public static void main(String[] args) throws Exception {
        SparseTests.World world = FastColdRestartTests.world();
        try (DimensionState s = new DimensionState(0, FastColdRestartTests.CONFIG, world)) {
            byte[] expected = world.snapshotIfReady(FastColdRestartTests.CUBE).fingerprint();
            for (int slot = 0; slot < 8; slot++) task(s, slot, expected);
            drain(s);
            check(s.restartMetrics.get("unique_dependency_checks") == 1, "same dependency checked repeatedly");
            check(s.restartMetrics.get("reused_dependency_checks") == 7, "positive checks not reused");
            world.change(FastColdRestartTests.CUBE, new byte[4096]);
            task(s, 0, expected); drain(s);
            check(s.restartMetrics.get("validation_dirty") == 1, "stale positive result survived revision change");
            check(s.restartMetrics.get("validation_stale_rechecks") == 1, "stale reuse not diagnosed");
            task(s, 1, expected); drain(s);
            check(s.restartMetrics.get("unique_dependency_checks") == 3, "negative result incorrectly reused");
        }
        System.out.println("VALIDATION_REUSE_PASS checks=" + checks);
    }
}
