package smog;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/** Wire compatibility, bounds, compact representations and active-graph equivalence. */
public final class GeometryPackV2Tests {
    static void check(boolean value,String why) { if(!value) throw new AssertionError(why); }
    static byte[] encode(GeometryPack pack,int version) throws Exception {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream(); pack.write(new DataOutputStream(bytes),version); return bytes.toByteArray();
    }
    static GeometryPack decode(byte[] bytes,int version) throws Exception {
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes));
        GeometryPack p=GeometryPack.read(in,0,version); check(in.read()==-1,"Trailing wire bytes"); return p;
    }
    static void labels() throws Exception {
        Random random=new Random(813215);
        for(int nodes:new int[]{0,1,2,254,255,256,512}) for(int run=0;run<8;run++) {
            int[] values=new int[512];
            for(int p=0;p<512;p++) values[p]=nodes==0 ? -1 : run==0 ? 0 : random.nextInt(nodes+1)-1;
            VoxelLabels source=VoxelLabels.of(values);
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            source.writeAdaptive(new DataOutputStream(bytes),nodes);
            int[] counts=new int[nodes];
            VoxelLabels decoded=VoxelLabels.readAdaptive(new DataInputStream(new ByteArrayInputStream(bytes.toByteArray())),nodes,counts);
            for(int p=0;p<512;p++) check(decoded.get(p)==values[p],"Adaptive membership changed");
            if(nodes==1 && run>0) check(decoded.payloadBytes()==64,"One-component obstacles not bitset");
        }
        for(byte[] bad:new byte[][]{{4},{1},{2},{0,0,1}}) {
            try { VoxelLabels.readAdaptive(new DataInputStream(new ByteArrayInputStream(bad)),0,new int[0]); throw new AssertionError("Invalid labels accepted"); }
            catch(IOException expected) {}
        }
        try { VoxelDistance.readAdaptive(new DataInputStream(new ByteArrayInputStream(new byte[]{2})),new byte[512]);
            throw new AssertionError("Invalid distance accepted"); } catch(IOException expected) {}
    }
    static void packs() throws Exception {
        for(String scene:new String[]{"open","obstacles","rooms","cavities","dense"}) {
            RestoreBenchmark.setup(scene,1024);
            for(byte[] template:RestoreBenchmark.templates()) {
                GeometryPack source=decode(template,1), decoded=decode(encode(source,2),2);
                check(source.key.equals(decoded.key),"Coordinate changed");
                check(Arrays.equals(source.volumes,decoded.volumes),"Volumes changed");
                check(Arrays.equals(source.seeds,decoded.seeds),"Seeds changed");
                check(Arrays.equals(source.contacts,decoded.contacts),"Contacts changed");
                check(Arrays.equals(source.boundary,decoded.boundary),"Boundary changed");
                check(Arrays.equals(source.dependencies,decoded.dependencies),"Halo changed");
                check(Arrays.deepEquals(source.fingerprints,decoded.fingerprints),"Fingerprints changed");
                for(int p=0;p<512;p++) {
                    check(source.labels.get(p)==decoded.labels.get(p),"Pack membership changed");
                    check(source.distance.get(p)==decoded.distance.get(p),"Distance changed");
                }
                byte[] wire=encode(source,2);
                // Node count beyond Cell8, invalid adaptive tag, truncation.
                byte[] bad=wire.clone(); bad[12]=2; bad[13]=1;
                try { decode(bad,2); throw new AssertionError("Node overflow accepted"); } catch(IOException expected) {}
                bad=wire.clone(); bad[14]=9;
                try { decode(bad,2); throw new AssertionError("Unknown tag accepted"); } catch(IOException expected) {}
                try { decode(Arrays.copyOf(wire,wire.length-1),2); throw new AssertionError("Truncation accepted"); } catch(IOException expected) {}
            }
        }
    }
    static void graph() throws Exception {
        Path v1=OptimisticRestoreTests.cache(), v2=OptimisticRestoreTests.cache();
        System.setProperty("smog.geometryPackVersion","1");
        Checkpoint.Data data=FastColdRestartTests.seed(v1,OptimisticRestoreTests.halo());
        System.setProperty("smog.geometryPackVersion","2");
        FastColdRestartTests.seed(v2,OptimisticRestoreTests.halo());
        try(DimensionState a=FastColdRestartTests.restore(data,v1,OptimisticRestoreTests.halo(),true,false);
            DimensionState b=FastColdRestartTests.restore(data,v2,OptimisticRestoreTests.halo(),true,false)) {
            FastColdRestartTests.drain(a); FastColdRestartTests.drain(b);
            check(a.topology().equals(b.topology()),"v1/v2 contacts differ");
            for(int i=0;i<80;i++) {
                a.tick(2000000,20,false); b.tick(2000000,20,false);
                FastColdRestartTests.near(a.liveMass(),b.liveMass(),"v1/v2 law4 mass");
                FastColdRestartTests.near(a.escapedMass(),b.escapedMass(),"v1/v2 law4 sinks");
            }
            for(Checkpoint.CellData cell:data.cells) for(int p=0;p<512;p++)
                FastColdRestartTests.near(a.sample(cell.key.block(p)),b.sample(cell.key.block(p)),"v1/v2 field");
            FastColdRestartTests.near(b.balanceError(),0,"v2 mass ledger");
        } finally { System.clearProperty("smog.geometryPackVersion"); }
        // New writer can merge a legacy region, then new readers accept the rewritten v2 file.
        System.setProperty("smog.geometryPackVersion","2");
        try(GeometryCache cache=new GeometryCache(v1,0,FastColdRestartTests.CONFIG,1048576)) {
            GeometryCache.Lookup old=cache.request(FastColdRestartTests.CUBE).get(5,TimeUnit.SECONDS);
            for(GeometryPack p:old.cells.values()) cache.store(p);
            cache.flush().get(5,TimeUnit.SECONDS);
        }
        try(GeometryCache cache=new GeometryCache(v1,0,FastColdRestartTests.CONFIG,1048576)) {
            check(cache.request(FastColdRestartTests.CUBE).get(5,TimeUnit.SECONDS).cells.size()==8,"Legacy merge lost packs");
        } finally { System.clearProperty("smog.geometryPackVersion"); }
    }
    public static void main(String[] args) throws Exception {
        labels(); packs(); graph();
        System.out.println("PASS GeometryPackV2Tests (all encodings, v1 compatibility, bounds, contacts, mass, law4)");
    }
}
