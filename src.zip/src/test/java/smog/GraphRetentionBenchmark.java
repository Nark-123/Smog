package smog;

import java.nio.file.Paths;
import java.lang.management.ManagementFactory;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** High-water capacity after all cells unload. No claim about live GTNH memory. */
public final class GraphRetentionBenchmark {
    static final class World extends RestoreBenchmark.World {
        boolean loaded=true;
        @Override public boolean isReady(CubeKey key) { return loaded && super.isReady(key); }
    }
    public static void main(String[] args) throws Exception {
        RestoreBenchmark.setup("open",Integer.parseInt(args[0]));
        System.setProperty("smog.bootstrapEnabled","false");
        byte[][] templates=RestoreBenchmark.templates();
        java.nio.file.Path directory=RestoreBenchmark.data(Paths.get(args[1]),templates);
        World world=new World();
        try(DimensionState state=Checkpoint.restore(RestoreBenchmark.checkpoint(templates),world)) {
            state.geometryCache(directory); state.resumeReadyCubes();
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(150);
            while(state.restartMetrics.get("restart_cells_published")<RestoreBenchmark.count) {
                state.geometry(2000000); Thread.yield();
                if(System.nanoTime()>deadline) throw new AssertionError("Restore deadline");
            }
            long before=state.graph.sparseBytes();
            world.loaded=false;
            for(DimensionState.CubeRecord cube:state.cubes.values()) state.onWorldCubeUnloading(cube.key,cube.epoch);
            long after=state.graph.sparseBytes();
            System.gc();
            System.out.printf(Locale.ROOT,"{\"cells\":%d,\"graph_bytes_live\":%d,\"graph_bytes_unloaded\":%d,\"live_nodes\":%d,\"parked_mass\":%.1f,\"retained_heap_bytes\":%d}%n",RestoreBenchmark.count,before,after,state.nodeCount(),state.parkedMass(),ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed());
        }
    }
}
