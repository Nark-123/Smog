package smog;

import java.nio.file.Path;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

/** Full DimensionState ticks behind the same server budget; no Minecraft dependencies. */
public final class MultiDimensionRestoreTests {
    static void check(boolean value,String why) { if(!value) throw new AssertionError(why); }
    static Checkpoint.Data checkpoint(int dimension,int cubes,SparseTests.World world,boolean ready) {
        Checkpoint.Data d=new Checkpoint.Data(); d.dimension=dimension; d.config=FastColdRestartTests.CONFIG; d.parts=20;
        for(int x=0;x<cubes;x++) {
            CubeKey key=new CubeKey(dimension,x,0,0); world.put(key,SparseTests.air(),1,1);
            if(!ready) world.ready.remove(key);
            for(int slot=0;slot<8;slot++) {
                Checkpoint.CellData c=new Checkpoint.CellData();
                c.key=new CellKey(dimension,x*2+(slot&1),(slot>>1)&1,(slot>>2)&1);
                c.mass=new DimensionState.MassRecord(new int[512],new int[]{512},new double[]{10});
                d.cells.add(c); d.injected+=10;
            }
        }
        return d;
    }
    static void dimensions() throws Exception {
        FastColdRestartTests.options(true,true,false);
        SparseTests.World first=new SparseTests.World(),late=new SparseTests.World(),background=new SparseTests.World();
        Checkpoint.Data a=checkpoint(0,128,first,true), b=checkpoint(1,2,late,false);
        CubeKey bg=new CubeKey(2,0,0,0); background.put(bg,SparseTests.air(),1,1);
        try(DimensionState active=Checkpoint.restore(a,first); DimensionState pending=Checkpoint.restore(b,late);
            DimensionState ordinary=new DimensionState(2,FastColdRestartTests.CONFIG,background)) {
            active.geometryCache(OptimisticRestoreTests.cache()); pending.geometryCache(OptimisticRestoreTests.cache());
            active.resumeReadyCubes(); pending.resumeReadyCubes(); FastColdRestartTests.drain(pending);
            check(pending.geometryWorkWeight()==0,"Unloaded dimension claimed a share");
            ordinary.queueAddMass(new BlockPos(2,1,1,1),10);
            GeometryWorkBudget budget=new GeometryWorkBudget();
            DimensionState[] states={active,pending,ordinary};
            int ordinaryAt=-1,lateAt=-1,firstBackgroundGrant=-1;
            for(int tick=0;tick<100;tick++) {
                if(tick==30) {
                    for(CubeKey key:late.all.keySet()) late.ready.add(key);
                    pending.columnEvent(0,0,false); pending.columnEvent(1,0,false);
                }
                long start=System.nanoTime(); budget.begin(start);
                for(DimensionState state:states) budget.offer(state,state.geometryWorkWeight());
                for(DimensionState state:states) {
                    int weight=state.geometryWorkWeight(); long grant=budget.grant(state,weight);
                    if(state==ordinary && grant>0 && firstBackgroundGrant<0) firstBackgroundGrant=tick;
                    if(state==pending && tick<30) check(grant==0,"Empty late dimension took active budget");
                    long now=System.nanoTime(); state.tick(2000000,20,false,grant);
                    budget.used(state,System.nanoTime()-now,state.lastGeometryNanos);
                }
                budget.end(System.nanoTime());
                if(ordinaryAt<0 && ordinary.publications>0) ordinaryAt=tick;
                if(lateAt<0 && pending.publications>0) lateAt=tick;
                Thread.yield();
            }
            check(firstBackgroundGrant>=0 && firstBackgroundGrant<=20 && ordinaryAt>=0,
                "Background dimension starved: grant="+firstBackgroundGrant+" publish="+ordinaryAt);
            check(lateAt>=30 && lateAt<100,"Late base never restored");
            check(active.iteration()>0 && pending.iteration()>0,"Restore paused solver");
            for(DimensionState state:states) FastColdRestartTests.near(state.balanceError(),0,"Multi-dimension ledger");
        }
    }
    static void ioWait() throws Exception {
        Path path=OptimisticRestoreTests.cache();
        Checkpoint.Data data=FastColdRestartTests.seed(path,FastColdRestartTests.world());
        try(DimensionState state=FastColdRestartTests.restore(data,path,FastColdRestartTests.world(),true,false)) {
            java.lang.reflect.Field field=GeometryCache.class.getDeclaredField("io"); field.setAccessible(true);
            ExecutorService io=(ExecutorService)field.get(state.geometryCache);
            CountDownLatch started=new CountDownLatch(1),release=new CountDownLatch(1);
            io.execute(() -> { started.countDown(); try { release.await(); } catch(InterruptedException ignored) {} });
            check(started.await(2,TimeUnit.SECONDS),"IO gate not started");
            try {
                for(int i=0;i<10;i++) state.geometry(1000000);
                check(state.geometryPending(),"IO plan was lost");
                check(state.geometryWorkWeight()==0,"Blocked IO claimed runnable budget");
            } finally { release.countDown(); }
            FastColdRestartTests.drain(state);
            check(state.liveMass()==80,"Deferred IO plan failed");
        }
    }
    static void discoveryUnderValidation() throws Exception {
        Path path=OptimisticRestoreTests.cache();
        SparseTests.World world=OptimisticRestoreTests.halo();
        Checkpoint.Data data=FastColdRestartTests.seed(path,world);
        for(int x=4;x<132;x++) {
            world.put(new CubeKey(0,x,0,0),SparseTests.air(),1,1);
            Checkpoint.CellData c=new Checkpoint.CellData(); c.key=new CellKey(0,x*2,0,0);
            c.mass=new DimensionState.MassRecord(new int[512],new int[]{512},new double[]{10});
            data.cells.add(c); data.injected+=10;
        }
        WorldSnapshotProvider busy=new WorldSnapshotProvider() {
            public boolean isReady(CubeKey key) { return world.isReady(key); }
            public ImmutableCubeSnapshot snapshotIfReady(CubeKey key) {
                long end=System.nanoTime()+450000L;
                while(System.nanoTime()<end) { /* bounded synthetic validation cost */ }
                return world.snapshotIfReady(key);
            }
        };
        FastColdRestartTests.options(true,true,false);
        try(DimensionState state=Checkpoint.restore(data,busy)) {
            state.geometryCache(path); state.resumeReadyCubes();
            OptimisticRestoreTests.plan(state,data);
            long unchecked=state.startup.unchecked;
            state.geometry(1000000);
            check(state.startup.unchecked<unchecked,"Busy validator starved ready-section discovery");
            check(state.startup.available>0,"Ready second base was not scheduled");
            FastColdRestartTests.near(state.balanceError(),0,"Discovery fairness ledger");
        }
    }
    public static void main(String[] args) throws Exception {
        dimensions(); ioWait(); discoveryUnderValidation();
        System.out.println("PASS MultiDimensionRestoreTests (three dimensions, background/late bases, IO sleep, solver, mass)");
    }
}
