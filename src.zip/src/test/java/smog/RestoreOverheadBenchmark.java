package smog;

import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/** Same harness above both exact delivered and new core classes. Synthetic, owner-thread world.
 * args: tag warm|cold scene cells dataset tick-period-ms wall-limit-ms backlog-frames */
public final class RestoreOverheadBenchmark {
    public static void main(String[] args) throws Exception {
        String tag = args[0], profile = args[1], scene = args[2];
        int count = Integer.parseInt(args[3]), period = Integer.parseInt(args[5]), backlog = Integer.parseInt(args[7]);
        long wallLimit = TimeUnit.MILLISECONDS.toNanos(Long.parseLong(args[6]));
        RestoreBenchmark.setup(scene, count);
        byte[][] templates = RestoreBenchmark.templates();
        Path root = Paths.get(args[4]); Files.createDirectories(root);
        Path directory = Files.createTempDirectory(root, "run-" + tag + "-" + profile + "-");
        if (profile.equals("warm")) {
            Path input = RestoreBenchmark.data(root, templates);
            try (java.util.stream.Stream<Path> files = Files.list(input)) {
                Path[] packs = files.filter(p -> p.getFileName().toString().endsWith(".gpk")).toArray(Path[]::new);
                for (Path pack : packs) Files.copy(pack, directory.resolve(pack.getFileName()));
            }
        }
        Checkpoint.Data data = RestoreBenchmark.checkpoint(templates);
        data.parts = 20; data.windows = backlog; data.ticks = 20L * backlog;
        BlockPos p = data.cells.get(0).key.block(0), q = data.cells.get(0).key.block(1);
        for (int i = 0; i < backlog; i++) data.frames.add(new DimensionState.Frame(
            new BlockPos[] {p, q}, new double[] {.01, .01}, .01));
        RestoreBenchmark.World world = new RestoreBenchmark.World();
        int ready = 0; for (Checkpoint.CellData c : data.cells) if (world.isReady(c.key.cube())) ready++;
        try (DimensionState state = Checkpoint.restore(data, world)) {
            state.geometryCache(directory); state.resumeReadyCubes();
            System.gc();
            long gc = RestoreBenchmark.gcCount(), gcMillis = RestoreBenchmark.gcMillis();
            Map<Long, Long> allocated = RestoreBenchmark.allocation();
            long cpuStart = ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime();
            long processStart = ((com.sun.management.OperatingSystemMXBean)ManagementFactory.getOperatingSystemMXBean()).getProcessCpuTime();
            long start = System.nanoTime(), nextProgress = start + TimeUnit.SECONDS.toNanos(10), activeNanos = 0;
            state.dimensionOpenedAt(start);
            long startTicks = state.gameTicks(), startSteps = state.iteration();
            int[] seconds = {1, 5, 10, 30, 60}; long[] progress = {-1, -1, -1, -1, -1};
            List<Double> calls = new ArrayList<>();
            double first = -1, ticks1200 = -1;
            while (state.restartMetrics.get("restart_cells_published") < ready && System.nanoTime() - start < wallLimit) {
                long tickStart = System.nanoTime();
                state.tick(2000000, 20, false, 2000000); // same actual grant, including validation; no boost
                long active = System.nanoTime() - tickStart; activeNanos += active; calls.add(active / 1e6);
                long elapsed = System.nanoTime() - start, published = (long)state.restartMetrics.get("restart_cells_published");
                if (first < 0 && published > 0) first = elapsed / 1e6;
                for (int i = 0; i < seconds.length; i++) if (progress[i] < 0 && elapsed >= seconds[i] * 1000000000L) progress[i] = published;
                if (ticks1200 < 0 && state.gameTicks() - startTicks >= 1200) ticks1200 = elapsed / 1e6;
                if (System.nanoTime() >= nextProgress) {
                    System.err.println("profile=" + profile + " published=" + published + " wall_ms=" + elapsed / 1e6
                        + " ticks=" + (state.gameTicks() - startTicks) + " frames=" + state.pendingIntervals());
                    nextProgress = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
                }
                long pause = period * 1000000L - (System.nanoTime() - tickStart);
                if (pause > 0) Thread.sleep(pause / 1000000, (int)(pause % 1000000));
            }
            double elapsed = (System.nanoTime() - start) / 1e6;
            long published = (long)state.restartMetrics.get("restart_cells_published");
            boolean completed = published == ready;
            if (completed) for (int i = 0; i < progress.length; i++) if (progress[i] < 0) progress[i] = published;
            // No new game time or geometry: finish only the already running candidate.
            for (int i = 0; state.graph.isStepInProgress() && i < 20; i++) state.finishPendingPart(20);
            state.updateRestartMemoryMetrics();
            RestartMetrics m = state.restartMetrics;
            if (Math.abs(state.balanceError()) > 1e-7 * Math.max(1, state.injectedMass())) throw new AssertionError("mass ledger");
            long allocation = RestoreBenchmark.allocated(allocated);
            long retained = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed();
            System.out.printf(Locale.ROOT, "{\"tag\":\"%s\",\"profile\":\"%s\",\"scene\":\"%s\",\"cells\":%d,\"ready_cells\":%d,\"published\":%d,\"completed\":%s,\"ms\":%.6f,\"first_ms\":%.6f,\"tick_period_ms\":%d,\"initial_frames\":%d,\"ticks\":%d,\"steps\":%d,\"wall_1200_ticks_ms\":%.6f,\"grant_per_tick_ns\":2000000,\"active_call_ms\":%.6f,\"server_cpu_ms\":%.6f,\"process_cpu_ms\":%.6f,\"tick_p95_ms\":%.6f,\"tick_p99_ms\":%.6f,\"tick_max_ms\":%.6f,\"allocated_bytes\":%d,\"heap_used_bytes\":%d,\"gc_count\":%d,\"gc_ms\":%d,\"balance_error\":%.12g,\"parked_mass\":%.12g,\"live_mass\":%.12g,\"removed_mass\":%.12g,\"pending_mass\":%.12g,\"progress\":{",
                tag, profile, scene, count, ready, published, completed, elapsed, first, period, backlog,
                state.gameTicks() - startTicks, state.iteration() - startSteps, ticks1200, activeNanos / 1e6,
                (ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime() - cpuStart) / 1e6,
                (((com.sun.management.OperatingSystemMXBean)ManagementFactory.getOperatingSystemMXBean()).getProcessCpuTime() - processStart) / 1e6,
                RestoreBenchmark.percentile(calls, .95), RestoreBenchmark.percentile(calls, .99), Collections.max(calls),
                allocation, retained, RestoreBenchmark.gcCount() - gc, RestoreBenchmark.gcMillis() - gcMillis,
                state.balanceError(), state.parkedMass(), state.liveMass(), state.removedMass(), state.pendingMass());
            for (int i = 0; i < seconds.length; i++) System.out.print((i == 0 ? "" : ",") + "\"" + seconds[i] + "s\":" + progress[i]);
            System.out.print("},\"metrics\":{");
            String[] names = m.csvHeader().split(","), values = m.csvValues().split(",");
            for (int i = 0; i < names.length; i++) System.out.print((i == 0 ? "" : ",") + "\"" + names[i] + "\":" + values[i]);
            System.out.print(",\"partition_ms\":" + state.geometryMetrics.phaseNanos[2] / 1e6
                + ",\"snapshot_ms\":" + state.geometryMetrics.phaseNanos[0] / 1e6
                + ",\"halo_ms\":" + state.geometryMetrics.phaseNanos[1] / 1e6
                + ",\"internal_contacts_ms\":" + state.geometryMetrics.phaseNanos[3] / 1e6
                + ",\"external_contacts_ms\":" + state.geometryMetrics.phaseNanos[4] / 1e6
                + ",\"prepared_full_calls\":" + state.geometryMetrics.preparedFullCalls
                + ",\"safe_wait_solver_calls\":" + state.geometryMetrics.waitSolverCalls
                + ",\"build_queue\":" + state.geometryQueues()[0] + ",\"prepared_queue\":" + state.geometryQueues()[2]);
            System.out.println("}}");
        }
    }
}
