package smog;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.SortedMap;
import java.util.concurrent.TimeUnit;

/** Region/micro contacts against the legacy cache path on non-uniform and atmospheric geometry. */
public final class EpochTopologyTests {
    private static final class World extends RestoreBenchmark.World {
        public boolean isReady(CubeKey k) {
            return k.dimension == 0 && k.x >= 0 && k.x < RestoreBenchmark.nx
                && k.y >= 0 && k.y < RestoreBenchmark.ny && k.z >= 0 && k.z < RestoreBenchmark.nz;
        }
    }
    private static void check(boolean ok, String why) { if (!ok) throw new AssertionError(why); }

    private static DimensionState restore(Checkpoint.Data data, Path directory, boolean epoch) {
        System.setProperty("smog.epochAppendRestoreEnabled", "" + epoch);
        DimensionState s = Checkpoint.restore(data, new World());
        s.geometryCache(directory); s.resumeReadyCubes(); return s;
    }
    public static void main(String[] args) throws Exception {
        for (int version : new int[] {1, 2}) for (String scene : new String[] {"open", "rooms", "dense", "atmosphere"}) {
            RestoreBenchmark.setup(scene, 64);
            byte[][] templates = RestoreBenchmark.templates();
            System.setProperty("smog.geometryPackVersion", "" + version);
            Path directory = RestoreBenchmark.data(Files.createTempDirectory(Paths.get("build"), "epoch-topology-"), templates);
            Checkpoint.Data d = RestoreBenchmark.checkpoint(templates);
            SortedMap<String, Double> topology;
            double[] reference = new double[64];
            try (DimensionState s = restore(d, directory, false)) {
                FastColdRestartTests.drain(s); topology = s.topology();
                s.addFrame(new DimensionState.Frame(new BlockPos[0], new double[0], 0));
                for (int part = 0; part < 20; part++) s.finishPendingPart(20);
                for (int i = 0; i < reference.length; i++) reference[i] = s.sample(d.cells.get(i).key.block(0));
            }
            for (boolean compact : new boolean[] {false, true}) {
                System.setProperty("smog.epochCompactContactsEnabled", "" + compact);
                System.setProperty("smog.epochMicroCells", "2");
                try (DimensionState s = restore(d, directory, true)) {
                    s.addFrame(new DimensionState.Frame(new BlockPos[0], new double[0], 0));
                    s.finishPendingPart(20); // Empty immutable epoch before any publication.
                    long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
                    while (s.restartMetrics.get("restart_cells_published") < 64 && System.nanoTime() < end) {
                        s.geometry(2000000); Thread.yield();
                    }
                    check(s.restartMetrics.get("restart_cells_published") == 64, "restore timeout " + scene);
                    check(s.topology().equals(topology), "edge/volume mismatch " + scene + " v" + version + " compact=" + compact);
                    for (int part = 1; part < 20; part++) s.finishPendingPart(20);
                    s.addFrame(new DimensionState.Frame(new BlockPos[0], new double[0], 0));
                    for (int part = 0; part < 20; part++) s.finishPendingPart(20);
                    for (int i = 0; i < reference.length; i++) {
                        double actual = s.sample(d.cells.get(i).key.block(0));
                        check(Math.abs(actual - reference[i]) <= 1e-11 * Math.max(1, Math.abs(reference[i])),
                            "next-epoch physics mismatch " + scene + " sample=" + i);
                    }
                    check(Math.abs(s.balanceError()) <= 1e-9, "ledger " + scene);
                }
            }
        }
        System.clearProperty("smog.epochMicroCells");
        System.clearProperty("smog.epochCompactContactsEnabled");
        System.out.println("EpochTopologyTests OK (4 geometries, v1/v2, compact contacts on/off, next-step tolerance 1e-11)");
    }
}
