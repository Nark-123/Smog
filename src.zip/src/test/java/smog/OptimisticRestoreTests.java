package smog;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

/** Deferred validation, real cache IO and active graph, synthetic immutable world. */
public final class OptimisticRestoreTests {
    static int checks;
    static void check(boolean ok, String message) {
        checks++;
        if (!ok) throw new AssertionError(message);
    }
    static Path cache() throws Exception { return Files.createTempDirectory(Paths.get("build"), "optimistic-"); }
    static void plan(DimensionState state, Checkpoint.Data data) throws Exception {
        FastRestorePlan plan = new FastRestorePlan(state, state.cell(data.cells.get(0).key, false));
        long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(5);
        while (plan.advance() != 0) {
            if (System.nanoTime() > end) throw new AssertionError("IO deadline");
            Thread.yield();
        }
    }
    static void noSnapshotsAndWaiting() throws Exception {
        Path path = cache();
        Checkpoint.Data data = FastColdRestartTests.seed(path, FastColdRestartTests.world());
        SparseTests.World world = FastColdRestartTests.world();
        try (DimensionState state = FastColdRestartTests.restore(data, path, world, true, false)) {
            long reads = world.reads;
            plan(state, data);
            check(world.reads == reads, "Optimistic publication acquired a world snapshot");
            check(state.nodeCount() == 8, "Incomplete atomic publication");
            check(state.cell(data.cells.get(0).key,false).geometry.epochs == null,
                "Optimistic publication allocated premature version arrays");
            check(state.geometryState(data.cells.get(0).key) == DimensionState.GeometryState.UNVERIFIED,
                "Missing halo incorrectly proved a match");
            long steps = state.iteration();
            state.tick(0, 1, false);
            state.tick(0, 1, false);
            check(state.iteration() > steps, "Unverified geometry blocked law4");
            FastColdRestartTests.drain(state);
            check(state.restartMetrics.get("validation_waiting") == 8, "Missing halo not parked");
            reads = world.reads;
            for (int n = 0; n < 100; n++) state.geometry(1000000);
            check(world.reads == reads, "Unavailable dependencies repeatedly scanned");
            SparseTests.near(state.balanceError(), 0, 1e-12, "Optimistic ledger");
        }
    }
    static void staleAndEdits() throws Exception {
        Path path = cache();
        Checkpoint.Data data = FastColdRestartTests.seed(path, FastColdRestartTests.world());
        SparseTests.World world = FastColdRestartTests.world();
        world.change(FastColdRestartTests.CUBE, new byte[4096]);
        try (DimensionState state = FastColdRestartTests.restore(data, path, world, true, false)) {
            plan(state, data);
            check(state.cellCount() == 8 && state.liveMass() == 80, "Stale topology did not activate first");
            FastColdRestartTests.drain(state);
            check(state.restartMetrics.get("validation_dirty") == 8, "Background missed changed blocks");
            SparseTests.near(state.trappedMass(), 80, 1e-12, "Rebuild lost trapped mass");
            SparseTests.near(state.balanceError(), 0, 1e-12, "Stale rebuild ledger");
        }
        path = cache();
        data = FastColdRestartTests.seed(path, FastColdRestartTests.world());
        world = FastColdRestartTests.world();
        try (DimensionState state = FastColdRestartTests.restore(data, path, world, true, false)) {
            FastRestorePlan preparing = new FastRestorePlan(state, state.cell(data.cells.get(0).key, false));
            world.change(FastColdRestartTests.CUBE, new byte[4096]);
            state.invalidateRegion(new BlockPos(0, 0, 0, 0), new BlockPos(0, 15, 15, 15));
            long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(5);
            while (preparing.advance() != 0 && System.nanoTime() < end) Thread.yield();
            check(state.nodeCount() == 0, "Session edit published a stale pending plan");
            FastColdRestartTests.drain(state);
            SparseTests.near(state.trappedMass(), 80, 1e-12, "Session edit lost mass");
        }
    }
    static SparseTests.World halo() {
        SparseTests.World world = FastColdRestartTests.world();
        for (int z = -1; z <= 1; z++) for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) {
            CubeKey key = new CubeKey(0, x, y, z);
            if (!key.equals(FastColdRestartTests.CUBE)) world.put(key, new byte[4096], 1, 1);
        }
        return world;
    }
    static void validatedAndRemap() throws Exception {
        Path path = cache();
        Checkpoint.Data data = FastColdRestartTests.seed(path, halo());
        Checkpoint.CellData first = data.cells.get(0);
        int[] split = new int[512];
        for (int p = 0; p < 512; p++) split[p] = p & 1;
        first.mass = new DimensionState.MassRecord(split, new int[] {256, 256}, new double[] {4, 6});
        DimensionState.Event event = new DimensionState.Event();
        event.add = 3;
        first.events.put(0, event);
        try (DimensionState state = FastColdRestartTests.restore(data, path, halo(), true, false)) {
            plan(state, data);
            check(state.geometryMetrics.coldFallbackCount == 1, "Different checkpoint topology skipped remapper");
            SparseTests.near(state.liveMass(), 83, 1e-12, "Pending event/remap contributions");
            FastColdRestartTests.drain(state);
            check(state.restartMetrics.get("validation_validated") == 8, "Complete matching halo not validated");
            for (Checkpoint.CellData cell : data.cells)
                check(state.geometryState(cell.key) == DimensionState.GeometryState.VALIDATED, "Wrong validation state");
            state.geometry(2000000);
            SparseTests.near(state.liveMass(), 83, 1e-12, "Event applied twice");
            SparseTests.near(state.balanceError(), 0, 1e-12, "Remap event ledger");
            SparseTests.World changed = halo();
            // Explicit session events keep their immediate invalidation path.
            state.invalidateBlocks(Collections.singleton(first.key.block(0)));
            check(state.geometryState(first.key) == DimensionState.GeometryState.DIRTY, "Session edit not immediate");
            FastColdRestartTests.drain(state);
        }
    }
    static void unloadDuringPrepare() throws Exception {
        Path path = cache();
        Checkpoint.Data data = FastColdRestartTests.seed(path, FastColdRestartTests.world());
        SparseTests.World world = FastColdRestartTests.world();
        try (DimensionState state = FastColdRestartTests.restore(data, path, world, true, false)) {
            FastRestorePlan plan = new FastRestorePlan(state, state.cell(data.cells.get(0).key, false));
            world.unload(state, FastColdRestartTests.CUBE);
            long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(5);
            while (plan.advance() != 0 && System.nanoTime() < end) Thread.yield();
            check(state.nodeCount() == 0, "Unloaded cube activated");
            SparseTests.near(state.parkedMass(), 80, 1e-12, "Unload lost checkpoint");
            world.load(state, FastColdRestartTests.CUBE);
            FastColdRestartTests.drain(state);
            SparseTests.near(state.balanceError(), 0, 1e-12, "Reload ledger");
        }
    }
    static void lateNeighbor() throws Exception {
        Path path = cache();
        SparseTests.World world = FastColdRestartTests.world();
        CubeKey neighbor = new CubeKey(0, 1, 0, 0);
        world.put(neighbor, SparseTests.air(), 1, 1);
        Checkpoint.Data data;
        FastColdRestartTests.options(true, false, false);
        try (DimensionState state = new DimensionState(0, FastColdRestartTests.CONFIG, world)) {
            state.geometryCache(path);
            for (int x = 0; x < 4; x++) for (int y = 0; y < 2; y++) for (int z = 0; z < 2; z++)
                state.queueAddMass(new CellKey(0, x, y, z).block(0), 10);
            FastColdRestartTests.drain(state);
            state.geometryCache.flush().get(5, TimeUnit.SECONDS);
            data = FastColdRestartTests.snapshot(state);
        }
        java.util.SortedMap<String, Double> expected;
        FastColdRestartTests.options(false, false, false);
        try (DimensionState state = Checkpoint.restore(data, world)) {
            state.resumeReadyCubes();
            FastColdRestartTests.drain(state);
            expected = state.topology();
        }
        world.ready.remove(neighbor);
        try (DimensionState state = FastColdRestartTests.restore(data, path, world, true, false)) {
            FastColdRestartTests.drain(state);
            check(state.cellCount() == 8, "Unloaded base expanded active graph");
            for (int i = 0; i < 2000; i++) state.tick(0, 20, false);
            world.load(state, neighbor);
            FastColdRestartTests.drain(state);
            check(state.restartMetrics.get("fast_restore_cells") == 16, "Late base lost fast path");
            check(expected.equals(state.topology()), "Late neighbor contacts duplicated or absent");
            SparseTests.near(state.balanceError(), 0, 1e-9, "Late neighbor ledger");
        }
    }
    static void lateFirstBaseAndStaleValidation() throws Exception {
        Path path = cache();
        Checkpoint.Data data = FastColdRestartTests.seed(path, FastColdRestartTests.world());
        SparseTests.World world = FastColdRestartTests.world();
        world.ready.clear();
        try (DimensionState state = FastColdRestartTests.restore(data, path, world, true, false)) {
            for (int i = 0; i < 216000; i++) state.tick(0,20,false); // three hours at 20 TPS
            while (state.graph.isStepInProgress()) state.finishPendingPart(20);
            world.load(state, FastColdRestartTests.CUBE);
            FastColdRestartTests.drain(state);
            check(state.restartMetrics.get("fast_restore_cells") == 8, "First base after three hours missed cache");
            check(state.gameTicks() == 216000, "Restore invented ticks");
        }
        path = cache();
        data = FastColdRestartTests.seed(path, halo());
        SparseTests.World initial = halo();
        SparseTests.World race = new SparseTests.World() {
            boolean armed = true;
            public ImmutableCubeSnapshot snapshotIfReady(CubeKey key) {
                ImmutableCubeSnapshot result = super.snapshotIfReady(key);
                if (armed && key.equals(FastColdRestartTests.CUBE)) {
                    armed = false;
                    change(key,new byte[4096]); // version changes after capture, before final check
                }
                return result;
            }
        };
        race.all.putAll(initial.all); race.ready.addAll(initial.ready);
        try (DimensionState state = FastColdRestartTests.restore(data,path,race,true,false)) {
            // Consume readiness registration before arming the publication's validation;
            // its legitimate wake-up would otherwise discard the same old result first.
            while (state.startup.pending()) state.startup.advance();
            plan(state,data);
            FastColdRestartTests.drain(state);
            check(state.restartMetrics.get("validation_stale") >= 1, "Stale validation result accepted");
            SparseTests.near(state.trappedMass(),80,1e-12,"Validation race lost mass");
        }
    }
    static void revisionEventDuringPrepare() throws Exception {
        Path path = cache();
        Checkpoint.Data data = FastColdRestartTests.seed(path,FastColdRestartTests.world());
        SparseTests.World world = FastColdRestartTests.world();
        try (DimensionState state = FastColdRestartTests.restore(data,path,world,true,false)) {
            state.onWorldCubeReady(FastColdRestartTests.CUBE,1,1);
            FastRestorePlan pending = new FastRestorePlan(state,state.cell(data.cells.get(0).key,false));
            world.put(FastColdRestartTests.CUBE,new byte[4096],1,2);
            state.onWorldCubeReady(FastColdRestartTests.CUBE,1,2);
            long end = System.nanoTime()+TimeUnit.SECONDS.toNanos(5);
            while(pending.advance()!=0 && System.nanoTime()<end) Thread.yield();
            check(state.nodeCount()==0,"Known session revision published old pending topology");
            FastColdRestartTests.drain(state);
            SparseTests.near(state.trappedMass(),80,1e-12,"Revision event lost mass");
        }
    }
    public static void main(String[] args) throws Exception {
        System.clearProperty("smog.optimisticRestore");
        noSnapshotsAndWaiting();
        staleAndEdits();
        validatedAndRemap();
        unloadDuringPrepare();
        lateNeighbor();
        lateFirstBaseAndStaleValidation();
        revisionEventDuringPrepare();
        System.out.println("PASS OptimisticRestoreTests checks=" + checks);
    }
}
