package smog;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

/** Exercises the real asynchronous writer with a conflicting pre-existing header. */
public final class EpochCsvTests {
    public static void main(String[] args) throws Exception {
        Class<?> type = Class.forName("org.smogmod.world.PerformanceFileLog");
        Constructor<?> constructor = type.getDeclaredConstructor(Path.class); constructor.setAccessible(true);
        Path dir = Files.createTempDirectory(Paths.get("build"), "epoch-csv-");
        Object log = constructor.newInstance(dir.resolve("perf.log"));
        Method offer = type.getDeclaredMethod("offerCsv", String.class, String.class); offer.setAccessible(true);
        Method written = type.getDeclaredMethod("written"); written.setAccessible(true);
        Method errors = type.getDeclaredMethod("errors"); errors.setAccessible(true);
        Method path = type.getDeclaredMethod("csvPath"); path.setAccessible(true);
        offer.invoke(log, "a,b", "1,2"); offer.invoke(log, "a,b", "3,4");
        offer.invoke(log, "a,b,c", "5,6,7");
        long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(3);
        while (((Long)written.invoke(log) < 2 || (Long)errors.invoke(log) < 1) && System.nanoTime() < end)
            Thread.yield();
        if ((Long)written.invoke(log) != 2 || (Long)errors.invoke(log) != 1)
            throw new AssertionError("CSV schema writer did not finish");
        String contents = new String(Files.readAllBytes(Paths.get((String)path.invoke(log))), StandardCharsets.UTF_8);
        if (!contents.equals("a,b\n1,2\n3,4\n")) throw new AssertionError("Mixed CSV schemas: " + contents);
        System.out.println("EpochCsvTests OK (matching headers append; mismatched header refused)");
    }
}
