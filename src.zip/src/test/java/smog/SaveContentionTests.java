package smog;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.smogmod.compat.gt5u.PendingPulse;
import org.smogmod.persistence.WorldStore;

/** Real Linux locks/failures; intentionally NOT a native Windows/ServerUtilities test. */
public final class SaveContentionTests {
    private static int checks;
    private static void check(boolean ok, String why) { checks++; if (!ok) throw new AssertionError(why); }
    private static long handles() {
        try (java.util.stream.Stream<Path> paths = Files.list(Paths.get("/proc/self/fd"))) { return paths.count(); }
        catch (IOException unavailable) { return -1; }
    }
    private static void acquisition() throws Exception {
        Class<?> type = Class.forName("org.smogmod.persistence.WorldStore$BundleLease");
        Method acquire = type.getDeclaredMethod("acquire", Path.class, long.class); acquire.setAccessible(true);
        Method acquireChannel = type.getDeclaredMethod("acquire", Path.class, long.class, FileChannel.class);
        acquireChannel.setAccessible(true);
        Path marker = Files.createTempDirectory(Paths.get("build"), "lease-").resolve(".in-progress");
        try (FileChannel owner = FileChannel.open(marker, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
             FileLock lock = owner.lock()) {
            long before = handles();
            for (int i = 0; i < 100; i++) {
                FileChannel failedChannel = FileChannel.open(marker, StandardOpenOption.WRITE);
                try { acquireChannel.invoke(null, marker, 10L, failedChannel); throw new AssertionError("overlapping lease accepted"); }
                catch (InvocationTargetException expected) { check(expected.getCause() instanceof IOException, "wrong lock failure"); }
                check(!failedChannel.isOpen(), "failed acquisition left its channel open");
                check(lock.isValid() && Files.exists(marker), "failed writer damaged another live marker/lock");
            }
            long after = handles();
            check(before < 0 || after <= before + 1, "failed lock acquisition leaked handles " + before + " -> " + after);
            System.out.println("lease_handles_before=" + before + " after=" + after);
        }
        ((AutoCloseable)acquire.invoke(null, marker, 10L)).close();
        check(!Files.exists(marker), "owned marker not removed after release");
        Thread.currentThread().interrupt();
        try { acquire.invoke(null, marker, 10L); throw new AssertionError("interrupted lease accepted"); }
        catch (InvocationTargetException expected) { check(expected.getCause() instanceof IOException, "wrong interruption failure"); }
        finally { Thread.interrupted(); }
        ((AutoCloseable)acquire.invoke(null, marker, 10L)).close();
    }
    private static final class FaultChannel extends FileChannel {
        final FileChannel delegate;
        final boolean releaseFailure, closeFailure;
        FaultChannel(FileChannel delegate, boolean releaseFailure, boolean closeFailure) {
            this.delegate = delegate; this.releaseFailure = releaseFailure; this.closeFailure = closeFailure;
        }
        public FileLock tryLock(long p, long n, boolean shared) throws IOException {
            final FileLock actual = delegate.tryLock(p, n, shared);
            return actual == null ? null : new FileLock(this, p, n, shared) {
                public boolean isValid() { return actual.isValid(); }
                public void release() throws IOException {
                    if (releaseFailure) throw new IOException("injected lease release failure");
                    actual.release();
                }
            };
        }
        public FileLock lock(long p, long n, boolean shared) throws IOException { return tryLock(p, n, shared); }
        protected void implCloseChannel() throws IOException {
            if (closeFailure) throw new IOException("injected channel close failure");
            delegate.close();
        }
        public int read(java.nio.ByteBuffer b) throws IOException { return delegate.read(b); }
        public long read(java.nio.ByteBuffer[] b, int o, int n) throws IOException { return delegate.read(b, o, n); }
        public int write(java.nio.ByteBuffer b) throws IOException { return delegate.write(b); }
        public long write(java.nio.ByteBuffer[] b, int o, int n) throws IOException { return delegate.write(b, o, n); }
        public long position() throws IOException { return delegate.position(); }
        public FileChannel position(long p) throws IOException { delegate.position(p); return this; }
        public long size() throws IOException { return delegate.size(); }
        public FileChannel truncate(long n) throws IOException { delegate.truncate(n); return this; }
        public void force(boolean metadata) throws IOException { delegate.force(metadata); }
        public long transferTo(long p, long n, java.nio.channels.WritableByteChannel c) throws IOException { return delegate.transferTo(p, n, c); }
        public long transferFrom(java.nio.channels.ReadableByteChannel c, long p, long n) throws IOException { return delegate.transferFrom(c, p, n); }
        public int read(java.nio.ByteBuffer b, long p) throws IOException { return delegate.read(b, p); }
        public int write(java.nio.ByteBuffer b, long p) throws IOException { return delegate.write(b, p); }
        public java.nio.MappedByteBuffer map(MapMode mode, long p, long n) throws IOException { return delegate.map(mode, p, n); }
    }
    private static void leaseCloseFaults() throws Exception {
        Class<?> type = Class.forName("org.smogmod.persistence.WorldStore$BundleLease");
        Method acquire = type.getDeclaredMethod("acquire", Path.class, long.class, FileChannel.class); acquire.setAccessible(true);
        for (boolean failedClose : new boolean[] {false, true}) {
            Path marker = Files.createTempDirectory(Paths.get("build"), "lease-close-fault-").resolve(".in-progress");
            try (FileChannel real = FileChannel.open(marker, StandardOpenOption.CREATE, StandardOpenOption.WRITE)) {
                FaultChannel channel = new FaultChannel(real, !failedClose, failedClose);
                AutoCloseable lease = (AutoCloseable)acquire.invoke(null, marker, 10L, channel);
                try { lease.close(); throw new AssertionError("lease cleanup failure hidden"); }
                catch (IOException expected) { check(expected.getMessage().startsWith("injected"), "cleanup cause lost"); }
                if (failedClose) check(Files.exists(marker), "unconfirmed channel close removed its marker");
                else check(!real.isOpen() && !Files.exists(marker), "release failure did not close the real channel");
            }
        }
    }

    private static void closeFailure() throws Exception {
        Path directory = Files.createTempDirectory(Paths.get("build"), "attachment-close-");
        try (DimensionState state = new DimensionState(0, FastColdRestartTests.CONFIG, FastColdRestartTests.world())) {
            CompletableFuture<Path> save = state.requestSave(directory, () -> new DimensionState.SaveAttachment() {
                public void commit(Path core) {}
                public void afterWrite() throws IOException { throw new IOException("injected release/close failure"); }
            });
            for (int i = 0; !save.isDone() && i < 10000; i++) { state.geometry(2000000); Thread.yield(); }
            try { save.get(5, TimeUnit.SECONDS); throw new AssertionError("cleanup IOException reported as success"); }
            catch (ExecutionException expected) { check(expected.getCause() instanceof IOException, "cleanup failure lost"); }
            CompletableFuture<Path> next = state.requestSave(directory);
            for (int i = 0; !next.isDone() && i < 10000; i++) { state.geometry(2000000); Thread.yield(); }
            next.get(5, TimeUnit.SECONDS);
        }
    }
    private static void pointerFailure() throws Exception {
        Path directory = Files.createTempDirectory(Paths.get("build"), "save-fault-cycles-");
        ArrayList<PendingPulse> pulses = new ArrayList<>();
        pulses.add(new PendingPulse(new BlockPos(0, 1, 1, 1), 17, false, true));
        WorldStore store = new WorldStore(directory);
        try (DimensionState state = new DimensionState(0, FastColdRestartTests.CONFIG, FastColdRestartTests.world())) {
            state.queueAddMass(new BlockPos(0, 1, 1, 1), 2);
            store.markDirty(); store.saveAndAwaitForShutdown(state, pulses, 5000);
            long before = handles();
            for (int i = 0; i < 20; i++) {
                byte[] current = Files.readAllBytes(directory.resolve("CURRENT"));
                Files.move(directory.resolve("CURRENT"), directory.resolve("current-held"));
                Files.createDirectory(directory.resolve("CURRENT"));
                Files.write(directory.resolve("CURRENT/blocked"), new byte[] {1});
                state.queueAddMass(new BlockPos(0, 1, 1, 1), 1); store.markDirty();
                long successes = store.completed;
                try { store.saveAndAwaitForShutdown(state, pulses, 5000); throw new AssertionError("pointer replacement failure hidden"); }
                catch (IOException expected) { check(store.completed == successes && store.failed == i + 1, "false WorldStore success"); }
                Files.delete(directory.resolve("CURRENT/blocked")); Files.delete(directory.resolve("CURRENT"));
                Files.move(directory.resolve("current-held"), directory.resolve("CURRENT"));
                check(java.util.Arrays.equals(current, Files.readAllBytes(directory.resolve("CURRENT"))), "CURRENT changed after failed commit");
                ArrayList<PendingPulse> restored = new ArrayList<>();
                try (DimensionState loaded = new WorldStore(directory).load(0, FastColdRestartTests.world(), restored)) {
                    check(restored.size() == 1 && restored.get(0).amount == 17, "failed save lost pulses");
                    check(Math.abs(loaded.balanceError()) < 1e-9, "old checkpoint ledger damaged");
                }
                store.markDirty(); store.saveAndAwaitForShutdown(state, pulses, 5000);
            }
            long after = handles(); check(before < 0 || after <= before + 1, "save fault cycles leaked handles");
            try (java.util.stream.Stream<Path> files = Files.walk(directory)) {
                check(files.noneMatch(p -> p.getFileName().toString().equals(".in-progress")), "orphan live marker after handled failures");
            }
            System.out.println("fault_cycle_handles_before=" + before + " after=" + after);
        }
    }
    public static void main(String[] args) throws Exception {
        acquisition(); leaseCloseFaults(); closeFailure(); pointerFailure();
        System.out.println("SAVE_CONTENTION_LINUX_PASS checks=" + checks + " native_windows=BLOCKED");
    }
}
