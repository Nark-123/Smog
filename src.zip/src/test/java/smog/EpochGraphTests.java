package smog;

/** Solver-only epoch equivalence; no world stubs, geometry cache or wall-clock assertions. */
public final class EpochGraphTests {
    private static int checks;

    private static void check(boolean value, String why) {
        checks++;
        if (!value) throw new AssertionError(why);
    }

    private static void bits(double a, double b, String why) {
        check(Double.doubleToLongBits(a) == Double.doubleToLongBits(b), why + ": " + a + " / " + b);
    }

    private static SmogGraph graph() {
        SmogGraph g = new SmogGraph(SmogConfig.throat8());
        for (int i = 0; i < 41; i++) {
            int id = g.newNode(i);
            g.setVolume(id, 4 + i);
            g.addNodeMass(id, 1000 + 123 * i);
            if (i % 3 == 0) g.sparseBoundary(id, .4);
        }
        for (int i = 0; i < 39; i++) {
            g.addEdge(i, i + 1, .3);
            if (i + 3 < 40) g.addEdge(i, i + 3, .7);
        }
        g.addEdge(39, 40, .6);
        g.removeNode(40); // Both a free node ID and a free edge ID must remain untouched by append.
        g.sparseSources(new int[] {0, 7, -1}, new double[] {13, 31, 19});
        return g;
    }

    private static void append(SmogGraph g, int batch) {
        int count = 57 << batch, start = g.allocatedNodeSlots(), edgeStart = g.allocatedEdgeSlots();
        g.beginAppendBatch(count, count);
        try {
            for (int i = 0; i < count; i++) {
                int id = g.newNode(100 + i);
                check(id == start + i, "reused node slot in append");
                g.setVolume(id, 9);
                g.addNodeMass(id, 5 + i);
                g.sparseBoundary(id, .2); // Must not enter only the second sink half.
                g.addEdge(i == 0 ? 7 : id - 1, id, .8);
                bits(g.nodeMass(id), 5 + i, "new mass not immediately visible");
            }
            check(g.allocatedEdgeSlots() == edgeStart + count, "reused edge slot");
        } finally {
            g.endAppendBatch();
        }
    }

    private static void denied(Runnable action) {
        boolean rejected = false;
        try { action.run(); } catch (IllegalStateException expected) { rejected = true; }
        check(rejected, "destructive mutation accepted mid-step");
    }

    private static void equivalence(int insertion) {
        SmogGraph reference = graph(), actual = graph();
        for (int part = 1; part <= 20; part++) {
            reference.sparsePart(20);
            actual.sparsePart(20);
            if (part == insertion) {
                for (int batch = 0; batch < 3; batch++) append(actual, batch);
                if (part < 20) {
                    check(actual.pendingSolverNodes() == 399, "pending activation count");
                    denied(() -> actual.newNode(0));
                    denied(() -> actual.removeNode(0));
                    denied(() -> actual.setVolume(0, 8));
                    denied(() -> actual.sparseBoundary(0, 0));
                    denied(() -> actual.addEdge(0, 1, 2));
                    denied(() -> actual.addNodeMass(0, 1));
                    denied(() -> actual.sparseSources(new int[] {0}, new double[] {1}));
                }
            }
        }
        for (int batch = 0; batch < 3; batch++) append(reference, batch);
        for (int id = 0; id < actual.allocatedNodeSlots(); id++)
            bits(reference.nodeMass(id), actual.nodeMass(id), "current epoch, insert " + insertion + ", node " + id);
        bits(reference.escapedMass(), actual.escapedMass(), "sink prefix");
        bits(reference.injectedMass(), actual.injectedMass(), "source snapshot");
        check(actual.pendingSolverNodes() == 0, "epoch did not finish");
        for (int part = 0; part < 20; part++) {
            reference.sparsePart(20);
            actual.sparsePart(20);
        }
        for (int id = 0; id < actual.allocatedNodeSlots(); id++)
            bits(reference.nodeMass(id), actual.nodeMass(id), "next epoch activation");
    }

    private static void cancellation(int insertion) {
        SmogGraph reference = graph(), actual = graph();
        for (int part = 0; part < insertion; part++) actual.sparsePart(20);
        append(actual, 0);
        actual.cancelStep();
        append(reference, 0);
        for (int id = 0; id < actual.allocatedNodeSlots(); id++)
            bits(reference.nodeMass(id), actual.nodeMass(id), "cancelled append");
        bits(reference.escapedMass(), actual.escapedMass(), "cancelled sinks");
        bits(reference.injectedMass(), actual.injectedMass(), "cancelled sources");
        for (int part = 0; part < 20; part++) { actual.sparsePart(20); reference.sparsePart(20); }
        for (int id = 0; id < actual.allocatedNodeSlots(); id++)
            bits(reference.nodeMass(id), actual.nodeMass(id), "replayed epoch");
    }

    private static void incrementalRelocation() {
        SmogGraph reference = graph(), actual = graph();
        int units = 0;
        while (!actual.prepareAppendCapacity(1000, 3000)) {
            reference.sparsePart(20); actual.sparsePart(20); units++;
            check(units < 200, "capacity preparation did not converge across steps");
        }
        if (units % 20 == 0) { reference.sparsePart(20); actual.sparsePart(20); units++; }
        append(actual, 0);
        while (units % 20 != 0) { reference.sparsePart(20); actual.sparsePart(20); units++; }
        append(reference, 0);
        for (int id = 0; id < actual.allocatedNodeSlots(); id++)
            bits(reference.nodeMass(id), actual.nodeMass(id), "incremental relocation lost partial computation");
    }

    public static void main(String[] args) {
        for (int insertion = 1; insertion <= 20; insertion++) equivalence(insertion);
        for (int insertion = 1; insertion < 20; insertion++) cancellation(insertion);
        incrementalRelocation();
        System.out.println("EpochGraphTests OK checks=" + checks + " (bitwise, all 20 insertion boundaries)");
    }
}
