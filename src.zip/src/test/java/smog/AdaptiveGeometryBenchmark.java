package smog;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Locale;
import java.lang.management.ManagementFactory;

/** Same semantic packs and zlib codec. Synthetic data, warm filesystem cache, fresh JVM per version. */
public final class AdaptiveGeometryBenchmark {
    static volatile long consume;
    public static void main(String[] args) throws Exception {
        int version=Integer.parseInt(args[0]);
        Path directory=Files.createTempDirectory(Paths.get("build"),"adaptive-codec-");
        System.out.print("["); boolean comma=false;
        for(String scene:new String[]{"open","obstacles","rooms","cavities","dense"}) {
            RestoreBenchmark.setup(scene,1024);
            byte[][] templates=RestoreBenchmark.templates();
            ByteArrayOutputStream bytes=new ByteArrayOutputStream(); DataOutputStream data=new DataOutputStream(bytes);
            data.writeByte(8);
            long labelPayload=0,distancePayload=0;
            for(byte[] t:templates) {
                GeometryPack p=GeometryPack.read(new DataInputStream(new ByteArrayInputStream(t)),0);
                p.write(data,version); labelPayload+=p.labels.payloadBytes(); distancePayload+=p.distance.payloadBytes();
            }
            data.flush(); byte[] cube=bytes.toByteArray(); Path file=directory.resolve(scene);
            try(DataOutputStream out=new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(file)))) {
                for(int i=0;i<128;i++) RecordCodec.write(out,cube);
            }
            for(int i=0;i<1000;i++) decode(cube,version);
            for(int warm=0;warm<2;warm++) try(DataInputStream in=new DataInputStream(new BufferedInputStream(Files.newInputStream(file)))) {
                for(int i=0;i<128;i++) decode(RecordCodec.read(in),version);
            }
            long before=RestoreBenchmark.ALLOC.getThreadAllocatedBytes(Thread.currentThread().getId());
            long cpu=ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime(),start=System.nanoTime();
            for(int repeat=0;repeat<32;repeat++) try(DataInputStream in=new DataInputStream(new BufferedInputStream(Files.newInputStream(file)))) {
                for(int i=0;i<128;i++) decode(RecordCodec.read(in),version);
            }
            long elapsed=System.nanoTime()-start,used=ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime()-cpu;
            long allocated=RestoreBenchmark.ALLOC.getThreadAllocatedBytes(Thread.currentThread().getId())-before;
            if(comma) System.out.print(","); comma=true;
            System.out.printf(Locale.ROOT,"{\"scene\":\"%s\",\"version\":%d,\"raw_cube_bytes\":%d,\"file_bytes\":%d,\"cells\":32768,\"read_decode_ms\":%.3f,\"cpu_ms\":%.3f,\"allocated_bytes\":%d,\"label_payload_per_cube\":%d,\"distance_payload_per_cube\":%d}",scene,version,cube.length,Files.size(file),elapsed/1e6,used/1e6,allocated,labelPayload,distancePayload);
        }
        System.out.println("]");
    }
    static void decode(byte[] raw,int version) throws Exception {
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(raw));
        if(in.readUnsignedByte()!=8) throw new AssertionError();
        for(int i=0;i<8;i++) {
            GeometryPack p=GeometryPack.read(in,0,version);
            consume+=p.volumes.length+p.labels.get(511)+p.distance.get(0);
        }
        if(in.read()!=-1) throw new AssertionError();
    }
}
